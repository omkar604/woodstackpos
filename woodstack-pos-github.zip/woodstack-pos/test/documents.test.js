"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startServer, team } = require("./helpers");

let srv, t;
before(async () => { srv = await startServer(); t = await team(srv); });
after(() => srv.stop());

test("seed data is loaded on first start", async () => {
  const cfg = await t.cashier.doc("config/main");
  assert.equal(cfg.exists, true);
  assert.equal(cfg.data.outlets.length, 11);
  assert.equal(cfg.data.registers.length, 13);
  const cat = await t.cashier.doc("catalog/c000");
  assert.ok(Object.keys(cat.data.fams).length >= 40);
});

test("set, get and versioning", async () => {
  let r = await t.cashier.write([{ op: "set", path: "customers/c1", data: { name: "Jay", tags: ["a"] } }]);
  assert.equal(r.status, 200);
  assert.equal(r.body.docs[0].version, 1);
  r = await t.cashier.write([{ op: "set", path: "customers/c1", data: { name: "Jay Carter" } }]);
  assert.equal(r.body.docs[0].version, 2);
  const d = await t.cashier.doc("customers/c1");
  assert.deepEqual(d.data, { name: "Jay Carter" });
  const missing = await t.cashier.doc("customers/none");
  assert.equal(missing.exists, false);
});

test("update merges objects and supports __inc, __push and __delete", async () => {
  await t.cashier.write([{ op: "set", path: "customers/c2", data: { name: "Mia", spent: 10, prefs: { size: "8", color: "black" }, list: [1] } }]);
  const r = await t.cashier.write([{ op: "update", path: "customers/c2", data: { spent: { __inc: 15.5 }, prefs: { color: { __delete: true }, fit: "wide" }, list: { __push: 2 } } }]);
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.docs[0].data, { name: "Mia", spent: 25.5, prefs: { size: "8", fit: "wide" }, list: [1, 2] });
});

test("update needs an existing document; merge creates one", async () => {
  const r = await t.cashier.write([{ op: "update", path: "customers/ghost", data: { name: "x" } }]);
  assert.equal(r.status, 400);
  const m = await t.cashier.write([{ op: "merge", path: "customers/ghost", data: { name: "x" } }]);
  assert.equal(m.status, 200);
  assert.equal(m.body.docs[0].version, 1);
});

test("a batch is all-or-nothing", async () => {
  const r = await t.cashier.write([
    { op: "set", path: "customers/batch1", data: { name: "ok" } },
    { op: "update", path: "customers/does-not-exist", data: { name: "fails" } }
  ]);
  assert.equal(r.status, 400);
  assert.equal((await t.cashier.doc("customers/batch1")).exists, false);
});

test("bad paths and bodies are rejected", async () => {
  for (const op of [
    { op: "set", path: "customers", data: {} },
    { op: "set", path: "customers/../x", data: {} },
    { op: "set", path: "customers/a b", data: {} },
    { op: "set", path: "customers/ok", data: [1, 2] },
    { op: "explode", path: "customers/ok", data: {} }
  ]) assert.equal((await t.cashier.write([op])).status, 400, JSON.stringify(op));
  assert.equal((await t.cashier.post("/api/write", { ops: [] })).status, 400);
});

test("delete removes a document", async () => {
  await t.cashier.write([{ op: "set", path: "customers/del1", data: { name: "x" } }]);
  const r = await t.cashier.write([{ op: "delete", path: "customers/del1" }]);
  assert.equal(r.status, 200);
  assert.equal((await t.cashier.doc("customers/del1")).exists, false);
});

test("query: filters, ordering and limits", async () => {
  await t.cashier.write([
    { op: "set", path: "customers/q1", data: { name: "A", visits: 1, cat: "vip", tags: ["x"] } },
    { op: "set", path: "customers/q2", data: { name: "B", visits: 5, cat: "customer", tags: ["y"] } },
    { op: "set", path: "customers/q3", data: { name: "C", visits: 9, cat: "vip", tags: ["x", "y"] } }
  ]);
  const names = docs => docs.filter(d => /^q\d$/.test(d.id)).map(d => d.data.name);
  assert.deepEqual(names(await t.cashier.query({ coll: "customers", where: [["cat", "==", "vip"]] })), ["A", "C"]);
  assert.deepEqual(names(await t.cashier.query({ coll: "customers", where: [["visits", ">=", 5]] })), ["B", "C"]);
  assert.deepEqual(names(await t.cashier.query({ coll: "customers", where: [["cat", "in", ["customer"]]] })), ["B"]);
  assert.deepEqual(names(await t.cashier.query({ coll: "customers", where: [["tags", "array-contains", "y"]] })), ["B", "C"]);
  const top = await t.cashier.query({ coll: "customers", where: [["visits", ">", 0]], orderBy: "visits", dir: "desc", limit: 2 });
  assert.deepEqual(top.map(d => d.data.name), ["C", "B"]);
  assert.equal((await t.cashier.post("/api/query", { coll: "customers", where: [["a.b", "==", 1]] })).status, 400);
});

test("live updates reach other screens over /api/events", async () => {
  const res = await fetch(srv.base + "/api/events", { headers: { cookie: t.manager.cookie } });
  assert.equal(res.status, 200);
  assert.match(res.headers.get("content-type"), /text\/event-stream/);
  const reader = res.body.getReader();
  const got = (async () => {
    let buf = "";
    while (!buf.includes("customers/live1")) { const { value, done } = await reader.read(); if (done) break; buf += Buffer.from(value).toString(); }
    return buf;
  })();
  await new Promise(r => setTimeout(r, 100));
  await t.cashier.write([{ op: "set", path: "customers/live1", data: { name: "Live" } }]);
  const buf = await Promise.race([got, new Promise((_, rej) => setTimeout(() => rej(new Error("no event")), 3000))]);
  assert.match(buf, /event: doc/);
  assert.match(buf, /"name":"Live"/);
  await reader.cancel();
});
