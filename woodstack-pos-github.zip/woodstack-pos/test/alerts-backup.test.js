"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startServer, team, SKU, OUT, famOf, stockPatch } = require("./helpers");
const { mockWhatsApp, waitFor } = require("./mocks");

let srv, t, wa;
before(async () => {
  wa = await mockWhatsApp();
  srv = await startServer({ env: { CALLMEBOT_TEST_BASE: wa.base, WHATSAPP_TEST_BASE: wa.base, ALERT_FLUSH_MS: "300" } });
  t = await team(srv);
});
after(async () => { await srv.stop(); await wa.close(); });

test("alert settings: owners change them, managers view them with keys masked", async () => {
  assert.equal((await t.cashier.get("/api/alerts/status")).status, 403);
  assert.equal((await t.manager.post("/api/alerts/settings", { enabled: true })).status, 403);
  const r = await t.owner.post("/api/alerts/settings", { enabled: true, negative: true, provider: "callmebot", recipients: [
    { name: "Owner", phone: "+1 718 555 0101", key: "123456", all: true },
    { name: "Flatbush lead", phone: "+1 718 555 0102", key: "123456", all: false, outlets: [OUT.FLATBUSH] },
    { name: "Bad key", phone: "+1 718 555 0103", key: "999", all: false, outlets: [OUT.IVY] }
  ] });
  assert.equal(r.status, 200);
  const st = await t.manager.get("/api/alerts/status");
  assert.equal(st.body.settings.recipients[0].key, "••••3456");
});

test("send test: works with a valid key, reports a clear error with a bad one", async () => {
  const people = (await t.owner.get("/api/alerts/status")).body.settings.recipients;
  assert.equal((await t.owner.post("/api/alerts/test", { id: people[0].id })).status, 200);
  assert.equal(wa.log.at(-1).phone, "+17185550101");
  const bad = await t.owner.post("/api/alerts/test", { id: people[2].id });
  assert.equal(bad.status, 502);
  assert.match(bad.body.error, /CallMeBot didn’t send/);
});

test("negative stock alert names the store, item, user and who is on the clock; only to people watching that store", async () => {
  wa.log.length = 0;
  await t.cashier.post("/api/clock", { action: "in", oi: OUT.FLATBUSH });
  await t.cashier.post("/api/clock", { action: "in", oi: OUT.FLATBUSH, login: "dan", password: "cashpass2" });
  const { fid, stock } = await famOf(t.cashier, SKU.BEA);
  await t.cashier.write([stockPatch(fid, SKU.BEA, OUT.FLATBUSH, -(stock[OUT.FLATBUSH] + 1))]); // 3 → -1
  const msgs = await waitFor(() => wa.log.length >= 2 && wa.log);
  assert.deepEqual(msgs.map(m => m.phone).sort(), ["+17185550101", "+17185550102"]);
  const text = msgs[0].text;
  assert.match(text, /NEGATIVE STOCK at WOODstack Flatbush/);
  assert.match(text, /Bea Mary Jane, size 8: now -1, changed by Carla Cashier/);
  assert.match(text, /On the clock at WOODstack Flatbush: .*Carla Cashier/);
  assert.match(text, /Dan Cashier/);
});

test("an item already below zero doesn't alert again as it drops further", async () => {
  wa.log.length = 0;
  const { fid } = await famOf(t.cashier, SKU.BEA);
  await t.cashier.write([stockPatch(fid, SKU.BEA, OUT.FLATBUSH, -1)]); // -1 → -2
  await new Promise(r => setTimeout(r, 900));
  assert.equal(wa.log.length, 0);
});

test("WhatsApp Business sends the approved template with store and details", async () => {
  wa.log.length = 0;
  await t.owner.post("/api/alerts/settings", { provider: "meta", meta: { phoneId: "1234567890", token: "EAAtest", template: "stock_alert", lang: "en_US", version: "v26.0" } });
  const { fid, stock } = await famOf(t.cashier, SKU.TIMB);
  await t.cashier.write([stockPatch(fid, SKU.TIMB, OUT.FLATBUSH, -(stock[OUT.FLATBUSH] + 1))]);
  const msgs = await waitFor(() => wa.log.length >= 2 && wa.log);
  const m = msgs[0];
  assert.equal(m.via, "meta");
  assert.equal(m.path, "/v26.0/1234567890/messages");
  assert.equal(m.auth, "Bearer EAAtest");
  assert.equal(m.body.template.name, "stock_alert");
  const [store, details] = m.body.template.components[0].parameters.map(p => p.text);
  assert.equal(store, "WOODstack Flatbush");
  assert.doesNotMatch(details, /\n/, "template variables can't contain line breaks");
  assert.match(details, /now -1/);
});

test("backups: owners can download a copy of the database", async () => {
  assert.equal((await t.manager.get("/api/backup")).status, 403);
  const r = await t.owner.get("/api/backup");
  assert.equal(r.status, 200);
  assert.match(r.headers.get("content-disposition"), /woodstack-pos-\d{4}-\d{2}-\d{2}\.db/);
  assert.equal(r.body.subarray(0, 15).toString(), "SQLite format 3");
  const st = await t.owner.get("/api/status");
  assert.ok(st.body.backups >= 1, "a nightly backup is written at startup");
});
