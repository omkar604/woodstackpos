"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startServer, team, SKU, OUT, famOf, sale, pushSale } = require("./helpers");

let srv, t;
before(async () => {
  srv = await startServer(); t = await team(srv);
  await t.cashier.write([
    { op: "set", path: "customers/jay", data: { name: "Jay Carter", cat: "vip" } },
    { op: "set", path: "customers/ana", data: { name: "Ana Ruiz", cat: "fnf", link: t.cashier.user.id } }
  ]);
});
after(() => srv.stop());

const bal = async id => (await t.cashier.doc("customers/" + id)).data.credit || 0;
const credit = (amount, cust = "jay") => sale({ lines: [{ sku: SKU.NB9060, n: "x", q: amount > 0 ? 1 : -1, p: 160, d: 0, net: amount > 0 ? 160 : -160, tax: 0 }], pays: [{ t: "Store Credit", a: amount }], cust });

test("customer types and linked employee are stored", async () => {
  const ana = await t.cashier.doc("customers/ana");
  assert.equal(ana.data.cat, "fnf");
  assert.equal(ana.data.link, t.cashier.user.id);
});

test("issuing store credit: managers only, with a reason", async () => {
  assert.equal((await t.cashier.post("/api/credit", { cust: "jay", amount: 50, reason: "x" })).status, 403);
  assert.equal((await t.manager.post("/api/credit", { cust: "jay", amount: 50, reason: "" })).status, 400);
  const r = await t.manager.post("/api/credit", { cust: "jay", amount: 50, reason: "Goodwill" });
  assert.equal(r.status, 200);
  assert.equal(r.body.balance, 50);
  assert.equal(await bal("jay"), 50);
  const ledger = await t.cashier.query({ coll: "credit", where: [["cust", "==", "jay"]] });
  assert.equal(ledger.length, 1);
  assert.deepEqual([ledger[0].data.type, ledger[0].data.amt, ledger[0].data.bal, ledger[0].data.note], ["Issued", 50, 50, "Goodwill"]);
});

test("paying with store credit takes it off the balance; overspending is refused", async () => {
  assert.equal((await t.cashier.write([pushSale(credit(30))])).status, 200);
  assert.equal(await bal("jay"), 20);
  const over = await t.cashier.write([pushSale(credit(30))]);
  assert.equal(over.status, 400);
  assert.match(over.body.error, /only \$20\.00/);
  assert.equal(await bal("jay"), 20, "a refused sale changes nothing");
  const noCust = await t.cashier.write([pushSale(credit(5, null))]);
  assert.equal(noCust.status, 400);
  assert.match(noCust.body.error, /Attach a customer/);
});

test("refunding to store credit adds to the balance", async () => {
  assert.equal((await t.cashier.write([pushSale(credit(-40))])).status, 200);
  assert.equal(await bal("jay"), 60);
});

test("voiding a sale paid with store credit gives the credit back", async () => {
  const s = credit(25); s.ri = 7;
  await t.cashier.write([pushSale(s)]);
  assert.equal(await bal("jay"), 35);
  const doc = await t.cashier.doc("sales/2026-11-06_r7");
  await t.cashier.write([{ op: "update", path: "sales/2026-11-06_r7", data: { sales: doc.data.sales.map(x => x.id === s.id ? { ...x, st: "void" } : x) } }]);
  assert.equal(await bal("jay"), 60);
  const types = (await t.cashier.query({ coll: "credit", where: [["cust", "==", "jay"]] })).map(d => d.data.type).sort();
  assert.deepEqual(types, ["Issued", "Paid with credit", "Paid with credit", "Refund to credit", "Sale voided"]);
});

test("setting a balance outright records the difference", async () => {
  const r = await t.owner.post("/api/credit", { cust: "ana", amount: 75, mode: "set", reason: "Imported balance" });
  assert.equal(r.body.balance, 75);
  const again = await t.owner.post("/api/credit", { cust: "ana", amount: 75, mode: "set", reason: "Imported balance" });
  assert.equal(again.body.unchanged, true);
});

test("sales history import: managers only, no duplicates, optional stock deduction", async () => {
  const sales = [
    { no: "HAR-1001", t: "2026-10-01T18:30:00.000Z", oi: OUT.HARLEM, lines: [{ sku: SKU.NB9060, n: "NB 9060", q: 1, p: 160, net: 160, tax: 14.2 }], pays: [{ t: "Credit Card", a: 174.2 }] },
    { no: "FLB-2001", t: "2026-10-02T15:05:00.000Z", oi: OUT.FLATBUSH, lines: [{ sku: SKU.BEA, n: "Bea", q: 2, p: 120, net: 240, tax: 0 }] }
  ];
  assert.equal((await t.cashier.post("/api/import/sales", { sales })).status, 403);
  const before = (await famOf(t.owner, SKU.BEA)).stock[OUT.FLATBUSH];
  const r = await t.manager.post("/api/import/sales", { sales, deduct: true });
  assert.equal(r.status, 200);
  assert.deepEqual(r.body, { imported: 2, skipped: 0 });
  assert.equal((await famOf(t.owner, SKU.BEA)).stock[OUT.FLATBUSH], before - 2);
  const again = await t.manager.post("/api/import/sales", { sales });
  assert.deepEqual(again.body, { imported: 0, skipped: 2 });
  const doc = await t.owner.doc("sales/2026-10-02_imp" + OUT.FLATBUSH);
  assert.equal(doc.data.sales[0].imp, true);
  assert.equal(doc.data.sales[0].pays[0].t, "Imported");
  assert.equal((await t.manager.post("/api/import/sales", { sales: [{ no: "x", t: "bad", oi: 0, lines: [] }] })).status, 400);
});
