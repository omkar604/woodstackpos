"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startServer, team } = require("./helpers");

let srv, t;
before(async () => { srv = await startServer(); t = await team(srv); });
after(() => srv.stop());

test("GET / serves the app with security headers", async () => {
  const r = await srv.client().get("/");
  assert.equal(r.status, 200);
  assert.match(r.headers.get("content-type"), /text\/html/);
  assert.equal(r.headers.get("x-frame-options"), "DENY");
  assert.equal(r.headers.get("x-content-type-options"), "nosniff");
  assert.match(r.headers.get("content-security-policy"), /default-src 'self'/);
  assert.match(r.body.toString(), /<title>WOODstack POS<\/title>/);
});

test("static files can't escape the public folder", async () => {
  for (const p of ["/../server.js", "/%2e%2e/server.js", "/..%2fdata/seed.json"]) {
    const r = await srv.client().get(p);
    assert.ok([403, 404].includes(r.status), `${p} → ${r.status}`);
    assert.doesNotMatch(r.body.toString(), /require\("node:http"\)/);
  }
});

test("API needs a login", async () => {
  const r = await srv.client().get("/api/me");
  assert.equal(r.status, 401);
  assert.equal((await srv.client().post("/api/write", { ops: [] })).status, 401);
});

test("login: wrong password is refused, right password sets an HttpOnly session cookie", async () => {
  const c = srv.client();
  const bad = await c.post("/api/login", { login: "carla", password: "nope" });
  assert.equal(bad.status, 401);
  assert.match(bad.body.error, /don’t match/);
  const ok = await c.post("/api/login", { login: "CARLA", password: "cashpass1" }); // logins are not case-sensitive
  assert.equal(ok.status, 200);
  assert.equal(ok.body.user.role, "cashier");
  assert.equal(ok.body.user.limit, 10);
  assert.match(ok.headers.get("set-cookie"), /HttpOnly/);
  assert.match(ok.headers.get("set-cookie"), /SameSite=Lax/);
  const me = await c.get("/api/me");
  assert.equal(me.status, 200);
  assert.equal(me.body.user.login, "carla");
  assert.equal(me.body.user.hash, undefined, "password hash must never be sent");
});

test("cookie gets Secure behind HTTPS", async () => {
  const r = await srv.client().post("/api/login", { login: "carla", password: "cashpass1" }, { "x-forwarded-proto": "https" });
  assert.match(r.headers.get("set-cookie"), /; Secure/);
});

test("cross-site POSTs are blocked", async () => {
  const r = await t.owner.post("/api/write", { ops: [{ op: "set", path: "customers/x", data: { name: "x" } }] }, { origin: "http://evil.example" });
  assert.equal(r.status, 403);
});

test("logout ends the session", async () => {
  const c = await srv.login("dan", "cashpass2");
  assert.equal((await c.post("/api/logout")).status, 200);
  assert.equal((await c.get("/api/me")).status, 401);
});

test("turning a login off ends its sessions and blocks new logins", async () => {
  const dan = await srv.login("dan", "cashpass2");
  const users = (await t.manager.get("/api/users")).body.users;
  const id = users.find(u => u.login === "dan").id;
  const r = await t.manager.post("/api/users", { id, name: "Dan Cashier", login: "dan", role: "cashier", active: false });
  assert.equal(r.status, 200);
  assert.equal((await dan.get("/api/me")).status, 401);
  assert.equal((await srv.client().post("/api/login", { login: "dan", password: "cashpass2" })).status, 401);
  await t.manager.post("/api/users", { id, name: "Dan Cashier", login: "dan", role: "cashier", active: true });
});

test("status, team and profiles", async () => {
  const st = await t.cashier.get("/api/status");
  assert.equal(st.status, 200);
  assert.match(st.body.version, /^\d{4}\.\d{2}\.\d{2}-\d+/);
  const team = await t.cashier.get("/api/team");
  assert.ok(team.body.team.some(u => u.name === "Mike Manager"));
  assert.ok(team.body.team.every(u => !("hash" in u) && !("salt" in u)));
  const id = team.body.team[0].id;
  const pr = await t.cashier.get("/api/profiles?ids=" + id);
  assert.equal(pr.body[id].name, team.body.team[0].name);
});

test("unknown endpoints return 404", async () => {
  assert.equal((await t.owner.get("/api/nope")).status, 404);
});

test("ten failed logins from one address lock it out for 15 minutes", async () => {
  const c = srv.client();
  for (let i = 0; i < 10; i++) await c.post("/api/login", { login: "carla", password: "wrong" + i });
  const r = await c.post("/api/login", { login: "carla", password: "cashpass1" });
  assert.equal(r.status, 429);
});
