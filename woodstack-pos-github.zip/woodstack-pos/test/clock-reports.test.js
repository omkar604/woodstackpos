"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startServer, team, SKU, OUT, sale, pushSale } = require("./helpers");

let srv, t;
before(async () => { srv = await startServer(); t = await team(srv); });
after(() => srv.stop());

test("time clock: in, break, end break, out", async () => {
  let r = await t.cashier.post("/api/clock", { action: "status" });
  assert.equal(r.body.state, "out");
  r = await t.cashier.post("/api/clock", { action: "in", oi: OUT.HARLEM });
  assert.equal(r.status, 200); assert.equal(r.body.state, "in"); assert.equal(r.body.oi, OUT.HARLEM);
  assert.equal((await t.cashier.post("/api/clock", { action: "in", oi: OUT.HARLEM })).status, 400, "no double clock-in");
  assert.equal((await t.cashier.post("/api/clock", { action: "resume" })).status, 400, "not on a break");
  r = await t.cashier.post("/api/clock", { action: "break" }); assert.equal(r.body.state, "break");
  r = await t.cashier.post("/api/clock", { action: "resume" }); assert.equal(r.body.state, "in");
  r = await t.cashier.post("/api/clock", { action: "out" }); assert.equal(r.body.state, "out");
  const p = (await t.manager.query({ coll: "punches", where: [["uid", "==", t.cashier.user.id]] }))[0].data;
  assert.equal(p.open, false);
  assert.equal(p.breaks.length, 1);
  assert.ok(p.breaks[0].e, "break was closed");
  assert.match(p.date, /^\d{4}-\d{2}-\d{2}$/);
});

test("someone else can clock in on the same register with their own login", async () => {
  const r = await t.cashier.post("/api/clock", { action: "in", oi: OUT.HARLEM, login: "dan", password: "cashpass2" });
  assert.equal(r.status, 200);
  assert.equal(r.body.name, "Dan Cashier");
  assert.equal((await t.cashier.post("/api/clock", { action: "out", login: "dan", password: "wrong" })).status, 403);
  assert.equal((await t.cashier.post("/api/clock", { action: "in", oi: 99 })).status, 400, "unknown store");
  const open = await t.cashier.query({ coll: "punches", where: [["open", "==", true]] });
  assert.equal(open.length, 1);
});

test("clock records can only be edited by managers", async () => {
  const [p] = await t.cashier.query({ coll: "punches", where: [["open", "==", true]] });
  assert.equal((await t.cashier.write([{ op: "update", path: "punches/" + p.id, data: { in: "2020-01-01T00:00:00Z" } }])).status, 403);
  assert.equal((await t.manager.write([{ op: "update", path: "punches/" + p.id, data: { edits: [{ reason: "test" }] } }])).status, 200);
});

test("report builder is for managers and owners", async () => {
  assert.equal((await t.cashier.get("/api/report/datasets")).status, 403);
  assert.equal((await t.cashier.post("/api/report", { dataset: "lines", metrics: ["units"] })).status, 403);
  const ds = (await t.manager.get("/api/report/datasets")).body;
  assert.deepEqual(Object.keys(ds).sort(), ["credit", "hours", "lines", "orders", "payments", "sales", "stock"]);
  assert.ok(ds.lines.dims.customer_type && ds.lines.metrics.margin);
  assert.equal((await t.manager.post("/api/report", { dataset: "nope", metrics: ["units"] })).status, 400);
  assert.equal((await t.manager.post("/api/report", { dataset: "lines", metrics: [] })).status, 400);
});

test("item sales report adds up by store", async () => {
  await t.owner.write([
    pushSale(sale({ oi: OUT.HARLEM, ri: 0, lines: [{ sku: SKU.NB9060, n: "NB", b: "New Balance", q: 2, p: 160, d: 0, net: 320, tax: 0, c: 88 }] })),
    pushSale(sale({ oi: OUT.FLATBUSH, ri: 7, lines: [{ sku: SKU.BEA, n: "Bea", b: "UGG", q: 1, p: 120, d: 10, net: 108, tax: 0, c: 60 }] }))
  ]);
  const r = await t.manager.post("/api/report", { dataset: "lines", from: "2000-01-01", to: "2100-01-01", group: ["outlet"], metrics: ["units", "revenue", "cost", "profit", "margin", "discount", "sales"], sort: "revenue", dir: "desc" });
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.columns.map(c => c.key), ["outlet", "units", "revenue", "cost", "profit", "margin", "discount", "sales"]);
  assert.deepEqual(r.body.rows[0], ["WOODstack Harlem", 2, 320, 176, 144, 45, 0, 1]);
  assert.deepEqual(r.body.rows[1], ["WOODstack Flatbush", 1, 108, 60, 48, 44.44, 12, 1]);
  assert.deepEqual(r.body.total, [3, 428, 236, 192, 44.86, 12, 2]);
});

test("filters: is, is not, contains", async () => {
  const run = filters => t.manager.post("/api/report", { dataset: "lines", from: "2000-01-01", to: "2100-01-01", group: ["brand"], metrics: ["units"], filters }).then(r => r.body.rows.map(x => x[0]).sort());
  assert.deepEqual(await run([{ dim: "outlet", op: "is", value: "WOODstack Harlem" }]), ["New Balance"]);
  assert.deepEqual(await run([{ dim: "brand", op: "not", value: "new balance" }]), ["UGG"]);
  assert.deepEqual(await run([{ dim: "outlet", op: "contains", value: "flat, harl" }]), ["New Balance", "UGG"]);
});

test("stock report values stock at cost and selling price", async () => {
  const r = await t.manager.post("/api/report", { dataset: "stock", group: ["outlet"], metrics: ["units", "cost_value", "retail_value", "negative"], filters: [{ dim: "sku", op: "is", value: SKU.AJ7 }] });
  assert.deepEqual(r.body.rows, [["WOODstack Warehouse", 4, 445.2, 840, 0]]);
});

test("hours report compares worked and scheduled", async () => {
  const today = (await t.manager.query({ coll: "punches" }))[0].data.date;
  await t.manager.write([{ op: "set", path: "shifts/s1", data: { uid: t.cashier.user.id, oi: OUT.HARLEM, date: today, start: "09:00", end: "17:30", breakMin: 30 } }]);
  const r = await t.manager.post("/api/report", { dataset: "hours", from: today, to: today, group: ["staff"], metrics: ["scheduled", "shifts"] });
  const carla = r.body.rows.find(x => x[0] === "Carla Cashier");
  assert.deepEqual(carla, ["Carla Cashier", 8, 1]);
});
