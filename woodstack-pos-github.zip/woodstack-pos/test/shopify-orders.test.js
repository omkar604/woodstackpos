"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startServer, team, SKU, OUT, famOf } = require("./helpers");
const { mockShopify, waitFor } = require("./mocks");

let srv, t, shop;
before(async () => {
  shop = await mockShopify();
  srv = await startServer({ env: { SHOPIFY_TEST_BASE: shop.base } });
  t = await team(srv);
});
after(async () => { await srv.stop(); await shop.close(); });

const orders = async () => Object.fromEntries((await t.owner.query({ coll: "orders" })).map(d => [d.data.name, { id: d.id, ...d.data }]));

test("Shopify settings: owners change them, managers can view, secrets are masked", async () => {
  assert.equal((await t.cashier.get("/api/shopify/status")).status, 403);
  assert.equal((await t.manager.post("/api/shopify/settings", { shop: "x" })).status, 403);
  assert.equal((await t.owner.post("/api/shopify/settings", { shop: "woodstack-test", clientId: "cid", clientSecret: "csecret" })).status, 200);
  const st = await t.manager.get("/api/shopify/status");
  assert.equal(st.status, 200);
  assert.equal(st.body.settings.clientSecret, "••••cret");
  assert.equal(st.body.settings.outlets[0], OUT.WAREHOUSE, "warehouse is picked first by default");
});

test("test connection uses the client credentials grant and lists active locations", async () => {
  const r = await t.owner.post("/api/shopify/test");
  assert.equal(r.status, 200);
  assert.equal(r.body.shop.name, "WOODstack");
  assert.deepEqual(r.body.locations.map(l => l.name), ["Clifton Warehouse"]);
  assert.ok(shop.log.some(x => x.type === "token" && x.grant === "client_credentials"));
});

test("a wrong client secret gives a clear error", async () => {
  await t.owner.post("/api/shopify/settings", { clientSecret: "wrong" });
  const r = await t.owner.post("/api/shopify/test");
  assert.equal(r.status, 500);
  await t.owner.post("/api/shopify/settings", { clientSecret: "csecret" });
  assert.equal((await t.owner.post("/api/shopify/test")).status, 200);
});

test("orders come in, matched by barcode and sent to the right location", async () => {
  await t.owner.post("/api/shopify/settings", { enabled: true, locationId: "gid://shopify/Location/1", locationName: "Clifton Warehouse", buffer: 1, syncOrders: true, pushStock: true });
  assert.equal((await t.manager.post("/api/shopify/refresh-variants")).body.variants, 4);
  const r = await t.manager.post("/api/shopify/sync-orders");
  assert.equal(r.body.created, 2);
  const o = await orders();
  assert.equal(o["#1001"].loc, OUT.WAREHOUSE, "AJ7 is in the warehouse");
  assert.equal(o["#1001"].unmatched, 1, "gift wrap has no barcode");
  assert.equal(o["#1001"].ship.city, "Brooklyn");
  assert.equal(o["#1002"].loc, OUT.WEB, "Bea is at WOODstack.com before the stores");
  assert.equal((await t.manager.post("/api/shopify/sync-orders")).body.created, 0, "no duplicates");
});

test("picking: cashiers record scans; they can't mark an order packed or shipped directly", async () => {
  const { id } = (await orders())["#1001"];
  assert.equal((await t.cashier.write([{ op: "merge", path: "orders/" + id, data: { picked: { 9001: 1 }, st: "picking" } }])).status, 200);
  assert.equal((await t.cashier.write([{ op: "merge", path: "orders/" + id, data: { st: "packed" } }])).status, 403);
  assert.equal((await t.cashier.write([{ op: "merge", path: "orders/" + id, data: { total: 0 } }])).status, 403);
});

test("packing needs every item scanned; only managers can pack anyway", async () => {
  const { id } = (await orders())["#1001"];
  const r = await t.cashier.post(`/api/orders/${id}/pack`, {});
  assert.equal(r.status, 400);
  assert.match(r.body.error, /scanned/);
  assert.equal((await t.cashier.post(`/api/orders/${id}/pack`, { force: true })).status, 403);
  await t.cashier.write([{ op: "merge", path: "orders/" + id, data: { picked: { 9001: 2, 9002: 1 } } }]);
  const before = (await famOf(t.owner, SKU.AJ7)).stock[OUT.WAREHOUSE];
  assert.equal((await t.cashier.post(`/api/orders/${id}/pack`, { boxes: 1 })).status, 200);
  assert.equal((await famOf(t.owner, SKU.AJ7)).stock[OUT.WAREHOUSE], before - 2, "packing takes stock out");
  assert.equal((await orders())["#1001"].st, "packed");
});

test("shipping sends a fulfillment with tracking to Shopify", async () => {
  const { id } = (await orders())["#1001"];
  assert.equal((await t.cashier.post(`/api/orders/${id}/ship`, { carrier: "UPS" })).status, 400, "tracking required");
  const r = await t.cashier.post(`/api/orders/${id}/ship`, { carrier: "UPS", number: "1Z999AA10123456784" });
  assert.equal(r.status, 200);
  assert.equal(r.body.shopifyUpdated, true);
  const f = shop.log.filter(x => x.type === "fulfill").pop().fulfillment;
  assert.deepEqual(f.lineItemsByFulfillmentOrder, [{ fulfillmentOrderId: "gid://shopify/FulfillmentOrder/77" }], "only open fulfillment orders");
  assert.deepEqual(f.trackingInfo, { company: "UPS", number: "1Z999AA10123456784" });
  assert.equal(f.notifyCustomer, true);
  assert.equal((await orders())["#1001"].st, "shipped");
});

test("stock goes to Shopify in the 2026 request format, with store buffers and open orders held back", async () => {
  shop.log.length = 0;
  const r = await t.manager.post("/api/shopify/push-all");
  assert.equal(r.status, 200);
  const calls = shop.log.filter(x => x.type === "stock");
  assert.ok(calls.length >= 1);
  const call = calls[0];
  assert.match(call.query, /@idempotent\(key: \$idempotencyKey\)/);
  assert.ok(call.variables.idempotencyKey);
  assert.equal(call.variables.input.name, "available");
  assert.ok(call.variables.input.quantities.every(q => "changeFromQuantity" in q && q.locationId === "gid://shopify/Location/1"));
  const qty = Object.fromEntries(calls.flatMap(c => c.variables.input.quantities).map(q => [q.inventoryItemId.split("/").pop(), q.quantity]));
  assert.equal(qty["1"], 2, "AJ7: 4 in warehouse minus 2 packed");
  assert.equal(qty["2"], 5, "Bea: web 1 + Flatbush 3-1 + Ivy 4-1, minus 1 waiting in #1002");
  assert.equal(qty["3"], 29, "NB 9060: six stores, each keeping 1 back");
});

test("unpack and cancel are manager-only and put stock back", async () => {
  const { id } = (await orders())["#1002"];
  await t.cashier.write([{ op: "merge", path: "orders/" + id, data: { picked: { 9003: 1 } } }]);
  await t.cashier.post(`/api/orders/${id}/pack`, {});
  const packed = (await famOf(t.owner, SKU.BEA)).stock[OUT.WEB];
  assert.equal((await t.cashier.post(`/api/orders/${id}/unpack`)).status, 403);
  assert.equal((await t.cashier.post(`/api/orders/${id}/cancel`)).status, 403);
  assert.equal((await t.manager.post(`/api/orders/${id}/cancel`)).status, 200);
  assert.equal((await famOf(t.owner, SKU.BEA)).stock[OUT.WEB], packed + 1);
  assert.equal((await orders())["#1002"].st, "cancelled");
});
