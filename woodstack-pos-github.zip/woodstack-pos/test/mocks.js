/*
 * Stand-ins for the outside services, so tests never touch the real Shopify or WhatsApp.
 * They answer the same requests the POS sends and record what they received.
 */
"use strict";
const http = require("node:http");

function listen(handler) {
  return new Promise(resolve => {
    const srv = http.createServer((req, res) => { let b = ""; req.on("data", c => b += c); req.on("end", () => handler(req, res, b)); });
    srv.listen(0, "127.0.0.1", () => resolve({ srv, base: `http://127.0.0.1:${srv.address().port}`, close: () => new Promise(r => srv.close(r)) }));
  });
}
const json = (res, code, x) => { res.writeHead(code, { "Content-Type": "application/json" }); res.end(JSON.stringify(x)); };

/* Shopify Admin API (GraphQL 2026-10) with two unfulfilled orders. */
async function mockShopify() {
  const log = [];
  const ORDERS = [
    { id: "gid://shopify/Order/5001", name: "#1001", createdAt: "2026-11-06T13:05:00Z", updatedAt: "2026-11-06T13:05:00Z", cancelledAt: null, displayFulfillmentStatus: "UNFULFILLED", displayFinancialStatus: "PAID", email: "jay@example.com", phone: null, note: "Gift",
      totalPriceSet: { shopMoney: { amount: "425.00" } }, shippingLine: { title: "UPS Ground" },
      shippingAddress: { name: "Jay Carter", address1: "55 Clinton St", address2: null, city: "Brooklyn", provinceCode: "NY", zip: "11201", countryCodeV2: "US", phone: null },
      lineItems: { nodes: [
        { id: "gid://shopify/LineItem/9001", title: "Air Jordan 7 Retro SP", variantTitle: "7", sku: "AJ7-7", quantity: 2, unfulfilledQuantity: 2, variant: { id: "gid://shopify/ProductVariant/1", barcode: "195870628741", sku: "AJ7-7" }, originalUnitPriceSet: { shopMoney: { amount: "210.00" } } },
        { id: "gid://shopify/LineItem/9002", title: "Gift wrap", variantTitle: "", sku: "", quantity: 1, unfulfilledQuantity: 1, variant: null, originalUnitPriceSet: { shopMoney: { amount: "5.00" } } }] } },
    { id: "gid://shopify/Order/5002", name: "#1002", createdAt: "2026-11-06T13:20:00Z", updatedAt: "2026-11-06T13:20:00Z", cancelledAt: null, displayFulfillmentStatus: "UNFULFILLED", displayFinancialStatus: "PAID", email: "mia@example.com", phone: null, note: null,
      totalPriceSet: { shopMoney: { amount: "120.00" } }, shippingLine: { title: "Standard" },
      shippingAddress: { name: "Mia Lopez", address1: "9 Ocean Ave", address2: null, city: "Brooklyn", provinceCode: "NY", zip: "11226", countryCodeV2: "US", phone: null },
      lineItems: { nodes: [{ id: "gid://shopify/LineItem/9003", title: "Bea Mary Jane", variantTitle: "8", sku: "", quantity: 1, unfulfilledQuantity: 1, variant: { id: "gid://shopify/ProductVariant/2", barcode: "197634808314", sku: "" }, originalUnitPriceSet: { shopMoney: { amount: "120.00" } } }] } }
  ];
  const VARIANTS = [["1", "195870628741"], ["2", "197634808314"], ["3", "197375084091"], ["4", "198483143878"]].map(([id, barcode]) => ({ id: "gid://shopify/ProductVariant/" + id, barcode, sku: "", displayName: "v" + id, inventoryItem: { id: "gid://shopify/InventoryItem/" + id, tracked: true } }));
  const m = await listen((req, res, b) => {
    if (req.url === "/admin/oauth/access_token") {
      const p = new URLSearchParams(b); log.push({ type: "token", grant: p.get("grant_type") });
      return p.get("client_id") === "cid" && p.get("client_secret") === "csecret" ? json(res, 200, { access_token: "shpat_test", scope: "read_orders", expires_in: 86399 }) : json(res, 400, { error: "invalid_client" });
    }
    if (req.url !== "/admin/api/2026-10/graphql.json") return json(res, 404, {});
    if (req.headers["x-shopify-access-token"] !== "shpat_test") return json(res, 401, { errors: "Invalid API key or access token" });
    const { query: q, variables: v } = JSON.parse(b);
    if (q.includes("shop {")) return json(res, 200, { data: { shop: { name: "WOODstack", myshopifyDomain: "woodstack-test.myshopify.com" }, locations: { nodes: [{ id: "gid://shopify/Location/1", name: "Clifton Warehouse", isActive: true }, { id: "gid://shopify/Location/2", name: "Closed", isActive: false }] } } });
    if (q.includes("productVariants(")) return json(res, 200, { data: { productVariants: { pageInfo: { hasNextPage: false, endCursor: null }, nodes: VARIANTS } } });
    if (q.includes("orders(")) { log.push({ type: "orders", q: v.q }); return json(res, 200, { data: { orders: { pageInfo: { hasNextPage: false, endCursor: null }, nodes: ORDERS } } }); }
    if (q.includes("fulfillmentOrders")) return json(res, 200, { data: { order: { fulfillmentOrders: { nodes: [{ id: "gid://shopify/FulfillmentOrder/77", status: "OPEN" }, { id: "gid://shopify/FulfillmentOrder/78", status: "CLOSED" }] } } } });
    if (q.includes("fulfillmentCreate")) { log.push({ type: "fulfill", fulfillment: v.fulfillment }); return json(res, 200, { data: { fulfillmentCreate: { fulfillment: { id: "gid://shopify/Fulfillment/1", status: "SUCCESS" }, userErrors: [] } } }); }
    if (q.includes("inventorySetQuantities")) {
      log.push({ type: "stock", query: q, variables: v });
      return json(res, 200, { data: { inventorySetQuantities: { userErrors: [] } } });
    }
    json(res, 200, { errors: [{ message: "mock: unknown query" }] });
  });
  return { ...m, log };
}

/* WhatsApp Cloud API + CallMeBot. CallMeBot key "123456" is valid, anything else is rejected. */
async function mockWhatsApp() {
  const log = [];
  const m = await listen((req, res, b) => {
    const u = new URL(req.url, "http://x");
    if (u.pathname === "/whatsapp.php") {
      const key = u.searchParams.get("apikey");
      log.push({ via: "callmebot", phone: u.searchParams.get("phone"), text: u.searchParams.get("text"), key });
      res.end(key === "123456" ? "Message queued. You will receive it in a few seconds." : "APIKey is invalid. You need to get a new one");
      return;
    }
    if (/^\/v\d+\.\d+\/[^/]+\/messages$/.test(u.pathname)) {
      const j = JSON.parse(b);
      log.push({ via: "meta", path: u.pathname, auth: req.headers.authorization, body: j });
      return json(res, 200, { messages: [{ id: "wamid.TEST" }] });
    }
    json(res, 404, {});
  });
  return { ...m, log };
}

const waitFor = async (fn, ms = 6000) => { const end = Date.now() + ms; while (Date.now() < end) { const v = await fn(); if (v) return v; await new Promise(r => setTimeout(r, 100)); } return fn(); };

module.exports = { mockShopify, mockWhatsApp, waitFor };
