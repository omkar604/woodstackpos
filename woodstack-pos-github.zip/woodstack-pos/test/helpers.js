/*
 * Test helpers: start a real POS server on a free port with its own empty data folder,
 * create staff logins, and talk to it like a browser would (cookie session, JSON).
 */
"use strict";
const { spawn, spawnSync } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const net = require("node:net");

const ROOT = path.resolve(__dirname, "..");

function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer();
    s.unref();
    s.on("error", reject);
    s.listen(0, "127.0.0.1", () => { const { port } = s.address(); s.close(() => resolve(port)); });
  });
}

const DEFAULT_USERS = [
  ["Olivia Owner", "owner1", "ownerpass1", "owner"],
  ["Mike Manager", "mike", "mgrpass1", "manager"],
  ["Carla Cashier", "carla", "cashpass1", "cashier"],
  ["Dan Cashier", "dan", "cashpass2", "cashier"],
  ["Vera Viewer", "vera", "viewpass1", "viewer"]
];

async function startServer({ users = DEFAULT_USERS, env = {} } = {}) {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "woodstack-test-"));
  fs.copyFileSync(path.join(ROOT, "data", "seed.json"), path.join(dataDir, "seed.json"));
  const baseEnv = { ...process.env, DATA_DIR: dataDir, NODE_NO_WARNINGS: "1", ...env };
  for (const u of users) {
    const r = spawnSync(process.execPath, [path.join(ROOT, "server.js"), "add-user", ...u], { env: baseEnv, encoding: "utf8" });
    if (r.status !== 0) throw new Error("add-user failed: " + r.stderr);
  }
  const port = await freePort();
  const child = spawn(process.execPath, [path.join(ROOT, "server.js")], { env: { ...baseEnv, PORT: String(port), HOST: "127.0.0.1" }, stdio: ["ignore", "pipe", "pipe"] });
  let out = "";
  child.stdout.on("data", d => { out += d; });
  child.stderr.on("data", d => { out += d; });
  await new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error("server did not start:\n" + out)), 15000);
    const check = () => { if (out.includes("listening on")) { clearTimeout(t); resolve(); } };
    child.stdout.on("data", check); check();
    child.on("exit", code => { clearTimeout(t); reject(new Error(`server exited (${code}):\n${out}`)); });
  });
  const base = `http://127.0.0.1:${port}`;

  function client(cookie = "") {
    const req = async (method, p, body, headers = {}) => {
      const res = await fetch(base + p, { method, headers: { ...(body !== undefined ? { "Content-Type": "application/json" } : {}), ...(cookie ? { cookie } : {}), ...headers }, body: body !== undefined ? JSON.stringify(body) : undefined });
      const sc = res.headers.get("set-cookie"); if (sc && /ws_sess=/.test(sc)) cookie = sc.split(";")[0];
      const type = res.headers.get("content-type") || "";
      const data = type.includes("json") ? await res.json() : Buffer.from(await res.arrayBuffer());
      return { status: res.status, body: data, headers: res.headers };
    };
    return {
      get: (p, h) => req("GET", p, undefined, h),
      post: (p, b = {}, h) => req("POST", p, b, h),
      write: ops => req("POST", "/api/write", { ops }),
      doc: p => req("GET", "/api/doc?path=" + encodeURIComponent(p)).then(r => r.body),
      query: q => req("POST", "/api/query", q).then(r => r.body.docs),
      get cookie() { return cookie; }
    };
  }
  async function login(loginName, password) {
    const c = client();
    const r = await c.post("/api/login", { login: loginName, password });
    if (r.status !== 200) throw new Error(`login ${loginName} failed: ${r.status} ${JSON.stringify(r.body)}`);
    c.user = r.body.user;
    return c;
  }
  async function stop() {
    if (child.exitCode === null) { child.kill("SIGTERM"); await new Promise(r => child.once("exit", r)); }
    fs.rmSync(dataDir, { recursive: true, force: true });
  }
  return { base, port, dataDir, client, login, stop, logs: () => out };
}

/* Logs in as each default role. */
async function team(srv) {
  const [owner, manager, cashier, cashier2, viewer] = await Promise.all(DEFAULT_USERS.map(([, l, p]) => srv.login(l, p)));
  return { owner, manager, cashier, cashier2, viewer };
}

/* Known items in data/seed.json (outlet index → starting stock). */
const SKU = {
  NB9060: "197375084091",    // New Balance 9060 10.5, $160: Linden 6, Broadway 6, Brownsville 7, Sheepsheadbay 6, Flatbush 4, Newark 6
  AJ7: "195870628741",       // Air Jordan 7 size 7, $210: WOODstack Warehouse 4
  AJ1: "198483143878",       // Air Jordan 1 High OG size 12, $185: WOODstack Warehouse 10
  BEA: "197634808314",       // UGG Bea Mary Jane size 8, $120: Flatbush 3, Ivy 4, WOODstack.com 1
  TIMB: "889588281908"       // Timberland 6-in boot 7.5, $185: Linden 1, Sheepsheadbay 1, Flatbush 1, Newark 2
};
const OUT = { HARLEM: 0, LINDEN: 2, FLATBUSH: 6, IVY: 8, WEB: 9, WAREHOUSE: 10 };

async function famOf(c, sku) {
  const d = await c.doc("catalog/c000");
  const [fid, f] = Object.entries(d.data.fams).find(([, f]) => f.v[sku]);
  return { fid, fam: f, stock: f.v[sku].st || {} };
}
const stockPatch = (fid, sku, oi, delta) => ({ op: "update", path: "catalog/c000", data: { fams: { [fid]: { v: { [sku]: { st: { [oi]: { __inc: delta } } } } } } } });

let saleSeq = 0;
function sale({ lines, pays = [], cust = null, oi = 0, ri = 0, extra = {} }) {
  const sub = Math.round(lines.reduce((a, l) => a + l.net, 0) * 100) / 100;
  return { id: "t" + Date.now().toString(36) + (++saleSeq), no: "T-" + saleSeq, t: new Date().toISOString(), oi, ri, lines, sub, tax: 0, tot: sub, cost: 0, items: lines.reduce((a, l) => a + l.q, 0), pays, cust, st: "done", ...extra };
}
const pushSale = (s, date = "2026-11-06") => ({ op: "merge", path: `sales/${date}_r${s.ri}`, data: { date, oi: s.oi, ri: s.ri, sales: { __push: s } } });

module.exports = { startServer, team, freePort, SKU, OUT, famOf, stockPatch, sale, pushSale, DEFAULT_USERS };
