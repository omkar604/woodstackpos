"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startServer, team, SKU, famOf, stockPatch } = require("./helpers");

let srv, t;
before(async () => { srv = await startServer(); t = await team(srv); });
after(() => srv.stop());

test("viewers can read but not write anything", async () => {
  assert.equal((await t.viewer.doc("config/main")).exists, true);
  for (const path of ["customers/v1", "sales/2026-11-06_r0", "registers/r0"]) {
    assert.equal((await t.viewer.write([{ op: "merge", path, data: { x: 1 } }])).status, 403, path);
  }
});

test("cashiers can work sales, customers, registers, transfers, counts and RFID", async () => {
  for (const path of ["customers/c1", "registers/r0", "transfers/t1", "closures/x1", "adjustments/a1", "rfid/pairs", "counts/k1"]) {
    assert.equal((await t.cashier.write([{ op: "merge", path, data: { note: "ok" } }])).status, 200, path);
  }
});

test("cashiers can change stock levels but not products or prices", async () => {
  const { fid } = await famOf(t.cashier, SKU.NB9060);
  assert.equal((await t.cashier.write([stockPatch(fid, SKU.NB9060, 2, -1)])).status, 200);
  assert.equal((await t.cashier.write([{ op: "update", path: "catalog/c000", data: { fams: { [fid]: { pr: 1 } } } }])).status, 403);
  assert.equal((await t.cashier.write([{ op: "update", path: "catalog/c000", data: { fams: { [fid]: { v: { [SKU.NB9060]: { o: "99" } } } } } }])).status, 403);
  assert.equal((await t.cashier.write([{ op: "set", path: "catalog/c999", data: { fams: {} } }])).status, 403);
  assert.equal((await t.manager.write([{ op: "update", path: "catalog/c000", data: { fams: { [fid]: { b: "New Balance" } } } }])).status, 200);
});

test("settings: managers change store setup, only owners change discount limits", async () => {
  assert.equal((await t.cashier.write([{ op: "update", path: "config/main", data: { x: 1 } }])).status, 403);
  assert.equal((await t.manager.write([{ op: "update", path: "config/main", data: { note: "m" } }])).status, 200);
  assert.equal((await t.manager.write([{ op: "merge", path: "config/discounts", data: { roles: { cashier: 50 } } }])).status, 403);
  assert.equal((await t.owner.write([{ op: "merge", path: "config/discounts", data: { roles: { cashier: 12 } } }])).status, 200);
  assert.equal((await t.cashier.get("/api/me")).body.user.limit, 12);
  await t.owner.write([{ op: "merge", path: "config/discounts", data: { roles: { cashier: 10 } } }]);
});

test("schedule, timesheets, saved reports and quick buttons are manager-only", async () => {
  for (const path of ["shifts/s1", "punches/p1", "reports/r1", "config/quickkeys"]) {
    assert.equal((await t.cashier.write([{ op: "set", path, data: { x: 1 } }])).status, 403, path);
    assert.equal((await t.manager.write([{ op: "set", path, data: { x: 1 } }])).status, 200, path);
  }
});

test("store credit can't be written directly by anyone", async () => {
  await t.owner.write([{ op: "set", path: "customers/sc", data: { name: "S" } }]);
  for (const c of [t.cashier, t.manager, t.owner]) {
    assert.equal((await c.write([{ op: "update", path: "customers/sc", data: { credit: 500 } }])).status, 403);
    assert.equal((await c.write([{ op: "set", path: "credit/x", data: { cust: "sc", amt: 500 } }])).status, 403);
  }
});

test("staff list: managers and owners only", async () => {
  assert.equal((await t.cashier.get("/api/users")).status, 403);
  const r = await t.manager.get("/api/users");
  assert.equal(r.status, 200);
  assert.ok(r.body.users.every(u => !("hash" in u)));
});

test("staff rules: who can create and change whom", async () => {
  assert.equal((await t.cashier.post("/api/users", { name: "X", login: "x1", password: "pass1234", role: "cashier" })).status, 403);
  const c = await t.manager.post("/api/users", { name: "New Cashier", login: "newc", password: "pass1234", role: "cashier" });
  assert.equal(c.status, 200);
  assert.equal((await t.manager.post("/api/users", { name: "New Mgr", login: "newm", password: "pass1234", role: "manager" })).status, 403);
  assert.equal((await t.owner.post("/api/users", { name: "New Mgr", login: "newm", password: "pass1234", role: "manager" })).status, 200);
  const me = t.manager.user;
  assert.equal((await t.manager.post("/api/users", { id: me.id, name: me.name, login: me.login, role: "owner" })).status, 403);
  const own = t.owner.user;
  assert.equal((await t.owner.post("/api/users", { id: own.id, name: own.name, login: own.login, role: "manager" })).status, 400, "can't change own role");
  assert.equal((await srv.client().post("/api/login", { login: "newc", password: "pass1234" })).status, 200);
  assert.equal((await t.owner.post("/api/users", { name: "Short", login: "short", password: "abc", role: "cashier" })).status, 400, "password too short");
});

test("individual discount limits: managers can give up to their own limit", async () => {
  const id = (await t.manager.get("/api/users")).body.users.find(u => u.login === "dan").id;
  assert.equal((await t.manager.post("/api/users", { id, name: "Dan Cashier", login: "dan", role: "cashier", disc: 25 })).status, 200);
  assert.equal((await t.manager.post("/api/users", { id, name: "Dan Cashier", login: "dan", role: "cashier", disc: 40 })).status, 403);
  assert.equal((await t.owner.post("/api/users", { id, name: "Dan Cashier", login: "dan", role: "cashier", disc: 40 })).status, 200);
  const mine = t.manager.user;
  assert.equal((await t.manager.post("/api/users", { id: mine.id, name: mine.name, login: mine.login, role: "manager", disc: 30 })).status, 403, "can't change own limit");
  const u = (await t.owner.get("/api/users")).body.users.find(x => x.login === "dan");
  assert.equal(u.limit, 40);
});

test("staff CSV import applies the same rules row by row", async () => {
  const r = await t.manager.post("/api/users/import", { rows: [
    { name: "Imp One", login: "imp1", password: "pass1234", role: "cashier", disc: 12 },
    { name: "Imp Mgr", login: "imp2", password: "pass1234", role: "manager" },
    { name: "Imp Bad", login: "imp3", password: "pass1234", role: "boss" }
  ] });
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.results.map(x => x.ok), [true, false, false]);
  assert.equal((await t.cashier.post("/api/users/import", { rows: [] })).status, 403);
});
