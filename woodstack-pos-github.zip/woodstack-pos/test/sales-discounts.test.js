"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startServer, team, SKU, famOf, sale, pushSale } = require("./helpers");

let srv, t;
before(async () => { srv = await startServer(); t = await team(srv); });
after(() => srv.stop());

const line = (sku, price, pct, extra = {}) => ({ sku, n: "Item", q: 1, p: price, d: pct, net: Math.round(price * (1 - pct / 100) * 100) / 100, tax: 0, ...extra });
const ring = (c, lines, more = {}) => c.write([pushSale(sale({ lines, ...more }))]);

test("full-price sales go through for any cashier", async () => {
  assert.equal((await ring(t.cashier, [line(SKU.NB9060, 160, 0)])).status, 200);
});

test("cashiers can discount up to their role limit (10%)", async () => {
  assert.equal((await ring(t.cashier, [line(SKU.NB9060, 160, 10)])).status, 200);
  const r = await ring(t.cashier, [line(SKU.NB9060, 160, 15)]);
  assert.equal(r.status, 403);
  assert.match(r.body.error, /over your 10% discount limit/);
});

test("a lower unit price counts as a discount too", async () => {
  const r = await ring(t.cashier, [{ sku: SKU.NB9060, n: "x", q: 1, p: 100, d: 0, net: 100, tax: 0 }]);
  assert.equal(r.status, 403);
});

test("managers can go to 30%, owners have no limit", async () => {
  assert.equal((await ring(t.manager, [line(SKU.NB9060, 160, 30)])).status, 200);
  assert.equal((await ring(t.manager, [line(SKU.NB9060, 160, 35)])).status, 403);
  assert.equal((await ring(t.owner, [line(SKU.NB9060, 160, 90)])).status, 200);
});

test("approvals: only someone whose limit covers the discount can approve it", async () => {
  const low = await t.cashier.post("/api/approve", { login: "dan", password: "cashpass2", pct: 25 });
  assert.equal(low.status, 403);
  assert.match(low.body.error, /doesn’t cover 25%/);
  const wrong = await t.cashier.post("/api/approve", { login: "mike", password: "bad", pct: 25 });
  assert.equal(wrong.status, 403);
  const ok = await t.cashier.post("/api/approve", { login: "mike", password: "mgrpass1", pct: 25 });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.limit, 30);
  assert.equal((await ring(t.cashier, [line(SKU.NB9060, 160, 25, { ap: ok.body.token })])).status, 200);
  assert.equal((await ring(t.cashier, [line(SKU.NB9060, 160, 40, { ap: ok.body.token })])).status, 403, "beyond the approver's limit");
  const forged = ok.body.token.slice(0, -4) + "AAAA";
  assert.equal((await ring(t.cashier, [line(SKU.NB9060, 160, 25, { ap: forged })])).status, 403);
});

test("completed sales can't be edited, but can be voided", async () => {
  const s = sale({ lines: [line(SKU.NB9060, 160, 0)], ri: 3 });
  await t.cashier.write([pushSale(s)]);
  const doc = await t.cashier.doc("sales/2026-11-06_r3");
  const edited = doc.data.sales.map(x => x.id === s.id ? { ...x, lines: [{ ...x.lines[0], net: 1 }] } : x);
  assert.equal((await t.cashier.write([{ op: "update", path: "sales/2026-11-06_r3", data: { sales: edited } }])).status, 403);
  const voided = doc.data.sales.map(x => x.id === s.id ? { ...x, st: "void" } : x);
  assert.equal((await t.cashier.write([{ op: "update", path: "sales/2026-11-06_r3", data: { sales: voided } }])).status, 200);
});

test("Gold SKUs: only owners mark them, change their price or approve discounts", async () => {
  const { fid } = await famOf(t.owner, SKU.AJ1);
  assert.equal((await t.manager.write([{ op: "update", path: "catalog/c000", data: { fams: { [fid]: { gold: true } } } }])).status, 403);
  assert.equal((await t.owner.write([{ op: "update", path: "catalog/c000", data: { fams: { [fid]: { gold: true } } } }])).status, 200);
  assert.equal((await t.manager.write([{ op: "update", path: "catalog/c000", data: { fams: { [fid]: { gold: false } } } }])).status, 403);
  assert.equal((await t.manager.write([{ op: "update", path: "catalog/c000", data: { fams: { [fid]: { pr: 150, stage: "md1", md1: 150 } } } }])).status, 403, "markdown is a price change");

  assert.equal((await ring(t.cashier, [line(SKU.AJ1, 185, 0)], { oi: 10, ri: 4 })).status, 200);
  const r = await ring(t.manager, [line(SKU.AJ1, 185, 5)], { oi: 10, ri: 4 });
  assert.equal(r.status, 403);
  assert.match(r.body.error, /Gold SKU/);
  const mgrApproval = (await t.cashier.post("/api/approve", { login: "mike", password: "mgrpass1", pct: 5, gold: true }));
  assert.equal(mgrApproval.status, 403, "managers can't approve Gold");
  const ownerApproval = (await t.cashier.post("/api/approve", { login: "owner1", password: "ownerpass1", pct: 20, gold: true })).body.token;
  assert.equal((await ring(t.cashier, [line(SKU.AJ1, 185, 20, { ap: ownerApproval })], { oi: 10, ri: 4 })).status, 200);
  assert.equal((await t.owner.write([{ op: "update", path: "catalog/c000", data: { fams: { [fid]: { gold: false } } } }])).status, 200);
});

test("cashiers can still change stock on a Gold item", async () => {
  const { fid } = await famOf(t.owner, SKU.AJ1);
  await t.owner.write([{ op: "update", path: "catalog/c000", data: { fams: { [fid]: { gold: true } } } }]);
  const r = await t.cashier.write([{ op: "update", path: "catalog/c000", data: { fams: { [fid]: { v: { [SKU.AJ1]: { st: { 10: { __inc: -1 } } } } } } } }]);
  assert.equal(r.status, 200);
});
