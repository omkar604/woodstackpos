# Who can do what

Four roles. Each one can do everything the role before it can.

| | Viewer | Cashier | Manager | Owner |
|---|:-:|:-:|:-:|:-:|
| **Look at everything** (sales, stock, customers, schedule) | ✓ | ✓ | ✓ | ✓ |
| Clock in and out, take breaks | ✓ | ✓ | ✓ | ✓ |
| Ring up sales, returns, voids | | ✓ | ✓ | ✓ |
| Discount up to own limit | | 10%¹ | 30%¹ | No limit |
| Approve someone else's discount (up to own limit) | | ✓ | ✓ | ✓ |
| Discount a Gold SKU, or approve one | | | | ✓ |
| Open and close registers | | ✓ | ✓ | ✓ |
| Add and edit customers | | ✓ | ✓ | ✓ |
| Pay or refund with store credit | | ✓ | ✓ | ✓ |
| Issue or remove store credit by hand | | | ✓ | ✓ |
| Stock counts, RFID counts, transfers | | ✓ | ✓ | ✓ |
| Pick, pack and ship online orders | | ✓ | ✓ | ✓ |
| Pack without scanning, unpack, cancel orders | | | ✓ | ✓ |
| Add and edit products, prices, markdowns | | | ✓ | ✓ |
| Mark or unmark Gold SKUs, change their prices | | | | ✓ |
| Store setup, taxes, quick buttons | | | ✓ | ✓ |
| Discount limits per role | | | | ✓ |
| Schedule shifts, fix timesheets | | | ✓ | ✓ |
| See own hours / everyone's hours | own | own | all | all |
| Report builder, saved reports | | | ✓ | ✓ |
| Import CSV: customers | | ✓ | ✓ | ✓ |
| Import CSV: products, stock, sales, staff | | | ✓ | ✓ |
| Create cashier and viewer logins, set their limits (up to own) | | | ✓ | ✓ |
| Create manager and owner logins | | | | ✓ |
| Shopify: view status, sync now | | | ✓ | ✓ |
| Shopify: connect and change settings | | | | ✓ |
| WhatsApp alerts: view / change | | | view | ✓ |
| Download a backup | | | | ✓ |

¹ Default role limits, changed by an owner in Setup → Discount limits. Anyone except an owner can be given an individual limit that replaces their role's limit.

Every rule above is checked by the server on every request, not just hidden in the screens. The test suite (`test/permissions.test.js`, `test/sales-discounts.test.js` and others) checks each one with real requests.

Also always true:
- Nobody can change their own role or turn off their own login. Only owners can change their own discount limit.
- There is always at least one active owner.
- Nobody edits a completed sale; it can only be voided or returned.
- Nobody types in a store credit balance. It only changes through sales, voids or **Issue store credit**, and every change is kept in history.
