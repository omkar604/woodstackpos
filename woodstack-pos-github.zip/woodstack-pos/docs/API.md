# API reference

Every screen in the POS talks to the server through this API. Anything the screens can do, a script can do too, with the same permission checks.

- **Base URL:** your POS address, e.g. `https://pos.woodstack.com`.
- **Format:** JSON in, JSON out. Send `Content-Type: application/json` on every `POST`.
- **Sessions:** `POST /api/login` sets an HttpOnly cookie, `ws_sess`, that lasts 30 days and renews as you use it. Send it back on every request.
- **Cross-site protection:** a `POST` whose `Origin` header doesn't match the server's host is refused with `403`.
- **Errors:** every error is `{ "error": "Plain-English message", "code": "invalid_argument" | "unavailable" | "quota_exceeded" }` with a matching status code:

| Status | Meaning |
|---|---|
| 400 | The request is wrong, or a business rule says no (e.g. not enough store credit) |
| 401 | Not logged in, or the session expired |
| 403 | Logged in, but your role can't do this |
| 404 | No such endpoint, order or document |
| 413 | Request body over 4 MB |
| 429 | Too many failed logins or approvals from this address (10 in 15 minutes) |
| 500 | Server fault. The message is generic; details go to the server log |

Roles, from least to most access: `viewer` < `cashier` < `manager` < `owner`. A minimum role of **any** means any logged-in user. See [PERMISSIONS.md](PERMISSIONS.md) for the full matrix.

---

## Sessions

### `POST /api/login`
No session needed.
```json
{ "login": "carla", "password": "…" }
```
`200` → `{ "user": { "id": "u_…", "name": "Carla Cashier", "login": "carla", "role": "cashier", "active": true, "disc": null, "limit": 10 } }`, plus the `ws_sess` cookie (`HttpOnly; SameSite=Lax`, plus `Secure` behind HTTPS).
`401` wrong login or password, or the login is turned off. `429` after 10 failures from one address in 15 minutes.

Logins are not case-sensitive. `limit` is the person's discount limit in percent (100 for owners).

### `POST /api/logout`
Any role. Ends this session.

### `GET /api/me`
Any role. `{ "user": { … } }`, the same shape as login.

---

## Documents

All shop data (catalog, sales, customers, orders and so on) is stored as JSON **documents** addressed by path: `collection/id`, or deeper, `collection/id/sub/id`. See [ARCHITECTURE.md](ARCHITECTURE.md#data-model) for each collection's shape.

### `GET /api/doc?path=customers/abc`
Any role.
```json
{ "path": "customers/abc", "coll": "customers", "id": "abc", "exists": true, "data": { "name": "Jay" }, "version": 3 }
```
A missing document returns `exists: false, data: null, version: 0`. It is not a 404.

### `POST /api/query`
Any role.
```json
{ "coll": "sales", "where": [["date", ">=", "2026-11-01"], ["oi", "==", 0]], "orderBy": "date", "dir": "desc", "limit": 50 }
```
- `where`: up to 10 `[field, op, value]` filters on top-level fields. `op` is one of `==` `!=` `<` `<=` `>` `>=` `in` `not-in` `array-contains`. `in` and `not-in` take 1 to 30 values.
- `orderBy`, `dir` (`asc` or `desc`) and `limit` (1 to 1000) are optional. Without `orderBy`, results come in id order.

`200` → `{ "docs": [ { path, coll, id, exists, data, version }, … ] }`

### `POST /api/write`
Role depends on the collection; see [PERMISSIONS.md](PERMISSIONS.md).
```json
{ "ops": [
  { "op": "set",    "path": "customers/abc", "data": { "name": "Jay" } },
  { "op": "update", "path": "customers/abc", "data": { "visits": { "__inc": 1 } } },
  { "op": "merge",  "path": "sales/2026-11-06_r0", "data": { "date": "2026-11-06", "sales": { "__push": { … } } } },
  { "op": "delete", "path": "customers/old" }
] }
```
| op | What it does |
|---|---|
| `set` | Replaces the whole document, or creates it |
| `update` | Deep-merges into an existing document. Fails if it doesn't exist |
| `merge` | Deep-merge that creates the document if it's missing |
| `delete` | Removes the document |

Special values inside `update` and `merge`:

| Value | Effect |
|---|---|
| `{ "__inc": n }` | Adds `n` to a number, safely when several registers write at once. Used for stock |
| `{ "__push": x }` | Appends `x` to an array. Used to add a sale to a register's day |
| `{ "__delete": true }` | Removes that field |

1 to 200 operations per request. They run in one transaction: if any fails, none are saved. `200` → `{ "docs": [ …new versions… ] }`.

Rules checked on every write:
- **Sales:** new sales must stay within the seller's discount limit, and Gold SKUs need an owner. Completed sales can't be edited, only voided. Store credit used must be available.
- **Catalog:** only owners mark, unmark or re-price Gold SKUs. Cashiers may only change stock counts.
- **Customers:** `credit` can't be changed directly.
- **`credit` collection:** never written directly. Use [`/api/credit`](#post-apicredit) or a sale.
- **`config/discounts`:** owners only.

### `GET /api/events`
Any role. A Server-Sent Events stream. Every saved document is sent to every open screen as:
```
event: doc
data: {"path":"catalog/c000","coll":"catalog","id":"c000","exists":true,"data":{…},"version":42}
```
There's a keep-alive comment every 25 seconds. Reconnect on drop; the stream advises 3 seconds.

---

## Sales and discounts

### `POST /api/approve`
Any role. A colleague types their own login on the register to approve a discount over the cashier's limit.
```json
{ "login": "mike", "password": "…", "pct": 25, "gold": false }
```
`200` → `{ "token": "…", "by": "Mike Manager", "limit": 30, "owner": false, "minutes": 15 }`

Put the `token` on each approved sale line as `ap`. It's valid for 15 minutes, and only up to the approver's limit. `gold: true` requires an owner. `403` wrong login, or the approver's limit doesn't cover `pct`.

### `POST /api/credit`
Manager or owner. Adds to or removes from a customer's store credit, with a reason kept in their history.
```json
{ "cust": "abc", "amount": 25, "reason": "Goodwill: late order" }
{ "cust": "abc", "amount": 100, "mode": "set", "reason": "Imported balance" }
```
`200` → `{ "balance": 125 }`, or `{ "balance": 100, "unchanged": true }`. `400` no reason given, an unknown customer, or the balance would go below zero.

How sales move credit:
- A payment `{ "t": "Store Credit", "a": 30 }` on a new sale takes 30 off the sale's customer.
- A negative amount (a refund) adds it back.
- Voiding the sale reverses it.

Each change writes a `credit/…` history entry.

### `POST /api/import/sales`
Manager or owner. Imports past sales from another system.
```json
{ "deduct": false, "sales": [
  { "no": "HAR-1001", "t": "2026-10-01T18:30:00Z", "oi": 0, "cust": null,
    "lines": [{ "sku": "197375084091", "n": "NB 9060", "q": 1, "p": 160, "net": 160, "tax": 14.2 }],
    "pays": [{ "t": "Credit Card", "a": 174.2 }] } ] }
```
Up to 5,000 sales per request. Sales are stored under `sales/{date}_imp{outlet}`, marked `imp: true`. A receipt number already imported for that day and outlet is skipped. With `deduct: true`, the items also come out of stock. `200` → `{ "imported": 2, "skipped": 0 }`.

---

## Online orders

Orders arrive from Shopify into `orders/{shopifyOrderId}`. Cashiers record picking with `/api/write`; they may only change `picked`, `st` (to `new` or `picking`), `loc`, `pickNote`, `pickBy` and `pickAt`.

### `POST /api/orders/{id}/pack`
Cashier or higher.
```json
{ "loc": 10, "boxes": 1, "force": false }
```
Every line must be scanned (`picked[lineId] >= q`). `force: true` packs without that, and is manager-only. Takes the items out of stock at `loc` and sets `st: "packed"`.

### `POST /api/orders/{id}/ship`
Cashier or higher.
```json
{ "carrier": "UPS", "number": "1Z999AA10123456784" }
{ "pickup": true }
```
The order must be packed. For Shopify orders with the connection on, this creates a Shopify fulfillment for every open fulfillment order, with tracking, and Shopify emails the customer if that setting is on. `200` → `{ "docs": […], "shopifyUpdated": true }`. `502` if Shopify refuses.

### `POST /api/orders/{id}/unpack`
Manager or owner. Puts the stock back and returns the order to `picking`.

### `POST /api/orders/{id}/cancel`
Manager or owner. Stops the order here, putting stock back if it was packed. It does **not** refund or cancel in Shopify.

---

## Shopify connection
All under `/api/shopify/`. Managers can view and trigger syncs; owners change settings.

| Endpoint | Role | Does |
|---|---|---|
| `GET status` | manager | Settings (secrets masked as `••••1234`), last sync times, products matched, open orders, recent errors |
| `POST settings` | owner | Saves any of `shop, clientId, clientSecret, accessToken, locationId, locationName, outlets[], buffer, enabled, syncOrders, pushStock, notify`. Masked values sent back unchanged are ignored |
| `POST test` | owner | Logs in to Shopify and returns `{ shop, locations }` (active locations only) |
| `POST refresh-variants` | manager | Re-matches Shopify variants to POS SKUs by barcode, then SKU → `{ variants }` |
| `POST sync-orders` | manager | Imports new and changed orders now → `{ created, updated }` |
| `POST push-all` | manager | Sends every matched item's online quantity now → `{ sent }` |

Online quantity = the sum over the chosen outlets of each outlet's stock (stores keep `buffer` back), minus items waiting in unpacked orders. It's sent with `inventorySetQuantities` using the `@idempotent` directive and `changeFromQuantity: null`, as Shopify requires from API version 2026-04.

---

## Staff

### `GET /api/team`
Any role. `{ "team": [ { "id", "name", "role", "active" } ] }`. Names for schedules and timesheets.

### `GET /api/profiles?ids=u_a,u_b`
Any role. `{ "u_a": { "id": "u_a", "name": "…" } }`.

### `GET /api/users`
Manager or owner. Full staff list, including `disc` (individual limit or null) and `limit` (effective limit).

### `POST /api/users`
Manager or owner. Create (no `id`) or update (with `id`):
```json
{ "id": "u_…", "name": "Dan Cashier", "login": "dan", "password": "", "role": "cashier", "active": true, "disc": 15 }
```
- Blank `password` keeps the current one. New logins need at least 4 characters.
- `disc` of `null` uses the role's limit.
- Managers can only create and change cashiers and viewers, and give limits up to their own.
- Nobody changes their own role, active flag or limit, except owners for their own limit.
- The last active owner can't be removed.

### `POST /api/users/import`
Manager or owner. `{ "rows": [ { name, login, password, role, disc, active } ] }`, up to 2,000. Each row follows the rules above, matched by login. `200` → `{ "results": [ { "ok": true, "login": "jane", "created": true } | { "ok": false, "login": "x", "error": "…" } ] }`.

---

## Time clock

### `POST /api/clock`
Any role.
```json
{ "action": "in", "oi": 0 }
{ "action": "out" }
{ "action": "break" }
{ "action": "resume" }
{ "action": "status" }
{ "action": "in", "oi": 0, "login": "dan", "password": "…" }
```
Without `login`, it acts for the logged-in user. With `login` and `password`, it acts for that person, so staff can clock in on a shared register. Times come from the server clock. `200` → `{ "name", "state": "in" | "break" | "out", "since", "clockedIn", "oi", "at" }`. `400` already clocked in, not clocked in, or not on a break. `403` wrong password.

Punches are stored in `punches/{id}`: `{ uid, oi, date, in, out, open, breaks: [{ s, e }], edits: [] }`. Managers fix them with `/api/write`; cashiers can't.

---

## Reports

### `GET /api/report/datasets`
Manager or owner. What each dataset can be grouped by (`dims`) and measured with (`metrics`).

| Dataset | One row per |
|---|---|
| `lines` | item sold |
| `sales` | receipt |
| `payments` | payment on a receipt |
| `hours` | clock-in and scheduled shift |
| `stock` | item at each store, now |
| `orders` | online order |
| `credit` | store credit history entry |

### `POST /api/report`
Manager or owner.
```json
{ "dataset": "lines", "from": "2026-11-01", "to": "2026-11-30",
  "group": ["outlet", "brand"], "metrics": ["units", "revenue", "profit", "margin"],
  "filters": [{ "dim": "outlet", "op": "is", "value": "WOODstack Harlem, WOODstack Flatbush" }],
  "sort": "revenue", "dir": "desc", "limit": 500, "includeVoid": false }
```
- `group`: up to 3 dimensions.
- `filters[].op`: `is`, `not` or `contains`. Comma-separate several values; matching isn't case-sensitive.
- Dates are store dates (`STORE_TZ`, default America/New_York).

`200` →
```json
{ "columns": [{ "key": "outlet", "label": "Store", "kind": "dim" }, …],
  "rows": [["WOODstack Harlem", "Nike", 12, 2100, 980, 46.67], …],
  "total": [null, …], "groups": 37, "sourceRows": 412 }
```
`total` lines up with the metric columns.

---

## WhatsApp alerts
All under `/api/alerts/`.

| Endpoint | Role | Does |
|---|---|---|
| `GET status` | manager | Settings (token and keys masked) and the last 25 alerts with delivery results |
| `POST settings` | owner | `enabled, negative, provider` (`callmebot` or `meta`), `meta: { phoneId, token, template, lang, version }`, `recipients: [{ id?, name, phone, key, all, outlets[], active }]` |
| `POST test` | owner | `{ "id": recipientId }` sends a test message. `502` with the provider's reason if it fails |

Alerts fire when an item's stock at a store **first drops below zero**, grouped per store over one minute (`ALERT_FLUSH_MS`).

---

## Admin

### `GET /api/status`
Any role. `{ "version": "2026.11.06-6 (…)", "docs": 1234, "lastBackup": "…", "backups": 12 }`.

### `GET /api/backup`
Owner. Downloads a consistent copy of the database (`woodstack-pos-YYYY-MM-DD.db`, SQLite).
