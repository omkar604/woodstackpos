# Woodstack POS: set up your own server

This puts the Woodstack POS on a server you rent and control. No Anthropic account is involved. Plan on about 45 minutes the first time. You don't need to know how to code. Copy and paste the commands exactly as shown.

**What you need**

- A card to pay for the server: about **$6 a month** for DigitalOcean's 1 GB server, plus about $1.20 for their automatic backups.
- Access to the settings for your domain (woodstack.com). That's wherever it was bought, such as GoDaddy, Namecheap, Squarespace or Cloudflare. If you don't know, ask whoever set up your website.
- This folder (`woodstack-pos`, which you unzipped).

---

## Step 1: Pick the web address

Choose an address for the POS, such as **pos.woodstack.com**. Staff will open it on every register. It doesn't affect your website.

## Step 2: Rent the server

1. Go to **digitalocean.com** and create an account.
2. Click **Create → Droplets**.
3. **Region:** New York. **Image:** Ubuntu 24.04 (LTS).
4. **Size:** Basic → Regular → **$6/month (1 GB RAM)**. That is plenty for 11 stores.
5. **Authentication:** choose **Password** and set a long one. Save it somewhere safe. This is the server's own password, separate from the POS logins.
6. Tick **Enable automated backups**.
7. Click **Create Droplet**. After a minute, copy its **IP address**. It looks like `164.90.123.45`.

(Any other provider such as Hetzner, Vultr or Linode works the same. You need Ubuntu 24.04 with at least 1 GB of memory.)

## Step 3: Point the web address at the server

At the company that manages woodstack.com, open the **DNS** settings and add a record:

| Type | Name / Host | Value / Points to | TTL |
|---|---|---|---|
| A | `pos` | your server's IP address | Automatic or 1 hour |

Save it. It can take a few minutes, and occasionally up to an hour, to start working.

## Step 4: Copy the POS to the server

**On a Mac:** open **Terminal** (press ⌘ Space and type Terminal).
**On Windows:** open **PowerShell** from the Start menu.

Type `cd ` (with a space after it), drag the folder that **contains** `woodstack-pos.zip` into the window, and press Enter. Then run this, swapping in your IP address:

```
scp woodstack-pos.zip root@164.90.123.45:/root/
```

Type `yes` if it asks about a fingerprint, then the server password from Step 2. Nothing appears on screen while you type the password, which is normal.

## Step 5: Run the installer

Log in to the server (same IP and password):

```
ssh root@164.90.123.45
```

Then paste these lines one at a time, using your own web address in the last one:

```
apt-get update && apt-get install -y unzip
unzip woodstack-pos.zip
cd woodstack-pos
bash install.sh pos.woodstack.com
```

The installer takes 2 to 4 minutes. At the end it asks for **your name, a login and a password**. That makes you the owner. When it says **Done**, type `exit`.

## Step 6: Log in and finish setup

1. Open **https://pos.woodstack.com** in a browser and log in.
2. Go to **Setup → Staff logins → Add staff** and make a login for each person:
   - **Cashier:** sells, returns, customers, stock counts and transfers. Can't change prices or settings.
   - **Manager:** everything a cashier does, plus products, prices, tax settings and cashier logins.
   - **Owner:** everything, plus managers and downloading backups.
   - **Viewer:** looks only.
3. Load your full catalog. In Lightspeed go to **Catalog → Products → Export**, then in the POS go to **Setup → Import from Lightspeed** and choose that file.
4. On each store's computer or iPad, open the address and **bookmark it** (on iPad, use Share → Add to Home Screen). Staff log in once per device and stay logged in for 30 days.

---

## Connect Shopify (WOODstack.com)

This brings online orders into the POS for pick and pack, and sends stock counts to Shopify so the website doesn't sell what you don't have.

> **Before you switch this on, turn off Lightspeed's Shopify sync.** If both systems send stock counts to Shopify, they'll overwrite each other.

**In Shopify** (the store owner has to do this part):

1. Go to **Settings → Apps → Develop apps → Build apps in Dev Dashboard**, and create an app called **Woodstack POS**.
2. Create a version of the app:
   - **App URL:** your POS address, such as `https://pos.woodstack.com`.
   - **Access scopes:** `read_products`, `read_inventory`, `write_inventory`, `read_locations`, `read_orders`, `read_merchant_managed_fulfillment_orders`, `write_merchant_managed_fulfillment_orders`.
   - **Protected customer data:** request access to **name, email, phone and address**. Without this, orders arrive with no shipping address.
   - **Release** the version.
3. **Install** the app on your store.
4. Copy the app's **Client ID** and **Client secret**.

**In the POS** (log in as the owner):

1. Go to **Setup → Shopify**.
2. Fill in **Store address** (your `something.myshopify.com` name, shown in Shopify under Settings → Domains), **Client ID** and **Client secret**.
3. Click **Test connection**. When it says *Connected*, choose the **Shopify location** your website ships from.
4. Under **Online stock comes from**, tick the locations that ship online orders. The first one ticked is tried first. By default that's the Clifton warehouse, then WOODstack.com, then Harrington Park, then the stores.
5. Set **Keep back per store**. The default of 1 means a store's last pair of each size stays for walk-in customers.
6. Tick **Connection on** and click **Save Shopify settings**.

What happens after that:
- The POS checks Shopify for new orders every 2 minutes.
- Each order goes to the first location that has every item. If no single location does, it goes to the one with the most items and is marked **Short**.
- Stock counts go to Shopify within about 20 seconds of any sale, count, transfer or packed order. Every item is also re-sent nightly.
- Products are matched by **barcode** first, then by SKU. **Setup → Shopify → Products matched** shows how many lined up. If that number is low, the barcodes in Shopify don't match the ones in the POS.
- Shopify keeps handling payments, refunds and customer emails.

## Pick and pack online orders

Any USB or Bluetooth barcode scanner that types like a keyboard works. Most do.

1. Open **Online**. The **To pick** tab lists orders waiting to go out. **Pick list** prints one combined list of everything to pull.
2. Open an order and scan each item. A good scan beeps and turns the row green. A wrong item gives a low buzz and a red message. Items without a barcode, like gift wrap, have a **+1** button.
3. When every item is scanned, click **Mark packed**. This takes the items out of stock at that location. **Packing slip** prints a slip for the box.
4. Choose the carrier, scan the shipping label's tracking number and click **Ship and notify customer**. Shopify marks the order fulfilled and emails the tracking to the customer. For store pickups, use **Customer picked up** instead.

Managers can change an order's location, **Pack anyway** when something won't scan, **Unpack** (which puts the stock back), and **Cancel here**. Cancelling here doesn't refund the customer; do that in Shopify too.

## RFID stock counts

Open **RFID count**. It counts the store, or one section, in minutes by reading every tagged item at once. Each tag counts only once, however many times the reader picks it up.

**Readers that work.** You need a handheld reader that can *type* each tag like a keyboard, one tag per line. Some can do this:
- **Android-based readers**, such as a Zebra RFD40 or RFD90 sled with Zebra's DataWedge app, or a Chainway C72 with its keyboard-emulator app. Set the output to *EPC in hex* with *Enter* after each tag. Open the POS in the device's browser.
- **USB desktop readers** in keyboard mode, for counting at the counter.
- **Any reader app that exports a file** (CSV or text). Use **Upload reader file** instead of reading live.

**Counting:**
1. Pick the store in the top bar and open **RFID count**.
2. Choose **Section count** to update only what you read, or **Full store count**, where anything not read is set to 0.
3. Click the big box and walk the floor and stockroom with the trigger held. The screen shows counted against the system as you go.
4. **Tags not recognized** lists tags that don't match a product. Most brand tags carry the item's UPC and match automatically. For the rest, click **Pair** and scan the item's barcode once; that tag is recognized from then on.
5. Click **Review and apply**, check the totals, then **Apply**. Each count is kept under **Recent counts**.

Count when the store is quiet. A sale rung up mid-count may need that item recounted. The count in progress is saved on that device, so you can stop and continue later.

## Customers: types and store credit

**Customer types.** Each customer is a **Customer**, **Reseller**, **VIP**, **Employee** or **Friends & family**.
- A Friends & family customer must be linked to the employee they know. An Employee customer can be linked to their staff login.
- The type shows next to the customer's name at the register and in the customer list, where you can filter by type.
- The report builder can group sales by **customer type** or **linked employee**, for example to see how much friends and family of each employee spend.

**Store credit.** Every customer has a store credit balance, with a full history of every change.
- **Paying with it:** attach the customer to the sale, then tap **Store Credit** on the payment screen. It uses as much of their balance as needed, up to what's owed, and the rest can be paid any other way. The receipt shows what's left.
- **Refunding to it:** on a return, attach the customer and tap **Store Credit** to put the refund on their balance.
- **Voiding** a sale paid with store credit puts the credit back automatically.
- **Issuing by hand:** managers and owners open the customer and use **Issue store credit**. Enter a positive amount to add, or a negative one to take away. A reason is required and is kept in the history.
- Nobody can type a new balance directly, and the server refuses any sale that spends more credit than the customer has.
- The customer CSV import can set opening balances (`store_credit` column, managers and owners only). The report builder's **Store credit** report shows credit added and used by day, customer, type or staff.

## Checking which version you're running

The version number is at the bottom of the left menu and in **Setup → Backups**. After installing an update, reload the page with **Ctrl + Shift + R** and check the number.

## WhatsApp alerts

When an item drops below zero at a store, the POS waits a minute to group any others, then sends one WhatsApp message per store. Each message names the store, every product and size that went negative with its new count, the staff member whose sale or change caused it, and everyone clocked in at that store at that moment. A sale of something the system thinks isn't there, or a transfer sent short, will trigger it. Set this up under **Setup → WhatsApp alerts** (owners only).

**Choose how to send.**
- **CallMeBot** is free and quick, and good for your own team's phones. Each person adds **+34 621 331 709** to their contacts and sends it the WhatsApp message `I allow callmebot to send me messages`. A reply comes back with their API key. CallMeBot occasionally changes that number, so check callmebot.com if no reply arrives. It's an unofficial service meant for personal use.
- **WhatsApp Business** is Meta's official service. In Meta Business Manager, set up the WhatsApp Cloud API and create a **Utility** message template with two variables, for example `Stock alert at {{1}}: {{2}}`. Once Meta approves it, enter the **phone number ID**, a permanent **access token** and the **template name**.

**Add people.** Enter each person's name, WhatsApp number with country code (e.g. +1 718 555 0100) and, for CallMeBot, their key. Then choose **All stores** or tick the stores they look after. Click **Save**, then **Send test** next to each person to check it arrives.

**Recent alerts** at the bottom shows every alert, who it went to, and any delivery problems.

## Time clock and schedule

**Clocking in and out:** tap **Time clock** at the top of any screen.
- The top half is for whoever is logged in on that register.
- **Someone else on this register** lets any other staff member clock in or out by typing their own login, without logging the register out.
- Breaks work the same way. The window also shows who's on the clock at that store.
- Times come from the server, not the register, so they can't be changed on the device.

**Schedule:** go to **Staff → Schedule**.
- Managers click a day to add a shift (store, start, end, unpaid break) or click a shift to change it.
- **Copy last week** fills the week from the one before.
- Everyone can see the schedule; only managers and owners can change it.

**Timesheets:** go to **Staff → Timesheets**.
- Shows each clock-in against the schedule, with **Late** flags (more than 5 minutes after the shift start) and weekly totals of hours worked against hours scheduled.
- Managers can fix an entry, such as a forgotten clock-out, or add a missed one. A reason is required and is kept with the entry.
- Cashiers see only their own hours.
- **Export CSV** sends the week's timesheet or schedule to payroll.

## Report builder

**Report builder** is open to owners and managers. Build any report in four choices:
1. **Report on:** items sold, sales (receipts), payments, hours worked against scheduled, stock on hand right now, or online orders.
2. **Dates:** quick picks like today, last week, this month or last year, or any custom range.
3. **Group by:** up to three columns, e.g. store, then staff, then brand; or month, then type. Options include date, week, month, day of week, hour, store, register, staff, customer, brand, type, product, size, SKU, Gold, price level and payment type.
4. **Numbers to show:** units, revenue, discount given, cost, gross profit, margin, tax, number of sales, average sale, items per sale, hours, value at cost, net cost, selling price, MSRP or internal price, and more.

Add filters (*store is Flatbush, Harlem*, *brand contains Jordan*, *staff is not Dan*), sort by any column, then **Run report**. Every report has totals, a chart and **Export CSV**. **Save this report** keeps it for every owner and manager. Date choices like "This week" always mean the current week when a saved report is re-run.

## Discount limits

- **Setup → Discount limits** (owners only) sets how much each level can take off an item without approval. Defaults: cashiers 10%, managers 30%. Owners have no limit.
- **Setup → Staff logins**: open a person and set an **Individual discount limit** to override their level. Leave it blank to use the level's limit. Managers can give cashiers limits up to their own; only owners can change managers' limits. Nobody but an owner can change their own.
- **At the register**, a discount over the cashier's limit shows **over limit** and payment is blocked. **Get approval** lets someone whose limit covers it, such as a manager, type their own login and approve. One approval covers the whole sale for 15 minutes. Raising the discount afterwards needs approval again.
- Gold SKUs always need an owner, whatever anyone's limit.
- The server checks every sale too, so the limits can't be bypassed.

## Importing from CSV

**Setup → Import and export** has an import for **products, staff, sales history, customers and stock counts**.

1. Click **Template** to download a starter file. Open it in Excel or Google Sheets.
2. Fill in one row per item, staff member, sale line, customer or count. Rows starting with `#` are ignored, so you can leave the template's example row in.
3. Save as CSV, then click **Import CSV** and choose the file.
4. The preview shows how many rows are ready and lists any problems by row number. Rows with problems are skipped.
5. Click **Import**.

Notes on each import:
- **Products** adds new products and updates existing ones by SKU/barcode. Blank cells leave a field unchanged. The `stock_` columns set the count at each store. Use **Export** to get your current catalog in the same format, edit it, and import it back.
- **Staff**: a blank password keeps an existing one. A blank `discount_limit` uses the role's limit.
- **Sales history**: rows with the same receipt number become one sale. Importing the same file twice won't double up. Leave "take out of stock" off for past sales.
- **Outlets** can be written as the full name ("WOODstack Harlem"), the code ("HAR") or a unique part of the name ("Harlem").
- **Dates** can be `2026-10-01`, `2026-10-01 14:30` or `10/01/2026 2:30 PM`.

## Quick buttons on the Sell screen

- **Product buttons.** A grid of one-tap buttons sits above the search on Sell. Managers and owners click **Edit quick buttons**, then **+ Add button**, pick a product, give it a short label and a colour. Click a button while editing to rename, recolour, move it earlier or remove it. Buttons are shared by every register. If a product has several sizes, tapping it opens a size picker that shows stock at that store.
- **Discount chips.** Tap 5%, 10%, 15% or 20% off under the sale discount. Each person's discount limit still applies.
- **Cash received.** On the payment screen, tap **Exact** or a round amount ($5, $10, $20, $50 or $100 up). The change due shows straight away.
- **Hold and resume.** **Hold** puts the current sale aside so you can serve someone else. **Held (n)** brings it back. Held sales stay on that register.

## Prices and markdowns

Each product has seven prices, all before tax: **supply price (cost)**, **supply price net**, **MSRP**, **first markdown**, **second markdown**, **close-out price** and **internal price**.

- **Register charges** picks which of MSRP, first markdown, second markdown or close-out the register uses. Marked-down items show the MSRP crossed out on the Sell screen and an MD1, MD2 or Close-out tag in the cart.
- **Markdowns in bulk:** in **Catalog**, filter by brand, type or search, then click **Change price level**. Products with no price for that level are left as they are.
- The editor shows the margin on cost and on net cost as you type.
- Supply price net and internal price are for your reference. The register doesn't charge them.
- Only managers and owners edit prices. Only an owner can change a Gold SKU's prices or price level.
- Importing from Lightspeed sets MSRP from Lightspeed's retail price. Re-importing keeps the markdown prices you've already entered.

## Gold SKUs

Gold SKUs are products that only an owner can discount.

- To mark one, an owner opens the product in **Catalog** and ticks **Gold SKU**. Only owners can tick or untick it.
- At the register, a Gold item shows a **GOLD** tag. Its discount box is replaced by an **Owner discount** button, and a discount on the whole sale skips it.
- If an owner is at the store, they press **Owner discount** and type their own login and password. The cashier can then discount that item for the next 15 minutes.
- The server checks every sale too. A Gold discount without an owner's approval is refused, even if someone tampers with the screen.

## Backups

- **Every night** the server saves a full copy of the POS and keeps the last 30.
- **DigitalOcean backups** (Step 2) save a copy of the whole server every week.
- **Download your own copy:** owners can use **Setup → Backups → Download backup now**. Do this weekly and keep the file somewhere safe, such as Google Drive or Dropbox.

## Installing an update

1. On your computer, copy the new zip to the server (Step 4).
2. Log in to the server and run these one at a time, using the same address you installed with:

```
rm -rf woodstack-pos
unzip -o woodstack-pos.zip
cd woodstack-pos
bash install.sh pos.woodstack.com
```

Your sales, stock and logins are kept. The installer skips the owner questions because logins already exist.

## Restoring a backup

Log in to the server (Step 5) and run the commands below. Swap the date for the backup you want; the backups folder lists them by date.

```
ls /opt/woodstack-pos/data/backups
systemctl stop woodstack-pos
cp /opt/woodstack-pos/data/backups/pos-2026-11-06.db /opt/woodstack-pos/data/pos.db
rm -f /opt/woodstack-pos/data/pos.db-wal /opt/woodstack-pos/data/pos.db-shm
chown woodstack:woodstack /opt/woodstack-pos/data/pos.db
systemctl start woodstack-pos
```

## If something's wrong

| Problem | What to do |
|---|---|
| The address doesn't open | Wait up to an hour after Step 3. Check the A record points to the right IP. |
| "Can't reach the POS server" | Check the store's internet. If every store sees it, restart the POS: log in to the server and run `systemctl restart woodstack-pos`. |
| Someone forgot their password | A manager or owner sets a new one in **Setup → Staff logins**. |
| The owner forgot their password | Log in to the server and run `cd /opt/woodstack-pos && sudo -u woodstack node server.js add-user "Your Name" yourlogin newpassword owner` |
| Anything else | Run `journalctl -u woodstack-pos -n 50` on the server and send the output to whoever is helping you. |

## What's in this folder

- `server.js`: the POS server. Built-in Node.js only, no outside packages.
- `shopify.js`: the Shopify connection.
- `alerts.js`: WhatsApp alerts.
- `reports.js`: the report builder.
- `public/`: the POS screens that load in the browser.
- `data/seed.json`: your outlets, registers, taxes and starter products, used only on the very first start.
- `install.sh`: the installer used in Step 5.
