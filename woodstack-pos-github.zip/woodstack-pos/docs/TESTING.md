# Testing

```bash
npm test          # all endpoint tests, about 5 seconds
npm run check     # syntax check of every server and browser file
node --test test/store-credit-imports.test.js   # one file
```

No setup is needed beyond Node 22.13 or newer. There's nothing to `npm install`.

## How the tests work

Each test file:
1. Starts a **real server** (`server.js`) on a free port, with its **own empty data folder** seeded from `data/seed.json`.
2. Creates five logins: owner, manager, two cashiers and a viewer (`test/helpers.js`).
3. Talks to it over HTTP exactly as the browser does: cookie session, JSON, Server-Sent Events.
4. For Shopify and WhatsApp, starts **stand-in services** (`test/mocks.js`) that answer the same requests the real ones do and record what they received. Nothing ever reaches the real Shopify or WhatsApp.

Files run in parallel, each with its own server, so they can't interfere with each other.

## What's covered

| File | Covers |
|---|---|
| `auth-http.test.js` | Serving the app, security headers, path-traversal protection, login, cookie flags, cross-site blocking, logout, deactivated logins, login rate limit, `status`, `team`, `profiles`, 404s |
| `documents.test.js` | Seed loading; `set` / `update` / `merge` / `delete`; `__inc`, `__push`, `__delete`; versioning; all-or-nothing batches; path validation; query filters, ordering, limits; live updates over `/api/events` |
| `permissions.test.js` | What viewers, cashiers, managers and owners can each write; cashier stock-only catalog changes; owner-only discount limits; manager-only schedule and timesheets; store credit can't be written directly; staff hierarchy rules; individual limits; staff CSV import |
| `sales-discounts.test.js` | Role discount limits; lower unit price counted as a discount; approvals (approver's limit, wrong password, forged token, beyond approver's limit); completed sales can't be edited but can be voided; Gold SKU rules end to end |
| `store-credit-imports.test.js` | Customer types and linked employee; issuing credit; paying, overspending, no customer; refund to credit; void returns credit; history entries; setting a balance; sales history import (permissions, dedupe, stock deduction, validation) |
| `shopify-orders.test.js` | Settings permissions and masking; client-credentials login; bad secret; order import and location assignment; picking permissions; pack rules (scans, manager force, stock taken out); ship with tracking → Shopify fulfillment; stock push format (`@idempotent`, `changeFromQuantity`), store buffer and reserved quantities; unpack and cancel |
| `clock-reports.test.js` | Clock in, break, end break, out; no double clock-in; clocking in someone else by their login; manager-only punch edits; report builder permissions and validation; exact totals by store; filters; stock valuation; hours against schedule |
| `alerts-backup.test.js` | Alert settings permissions and masking; test messages (valid and invalid key); negative-stock message content (store, item, user, who's on the clock) and recipients per store; no repeat alerts; WhatsApp Business template format; owner-only backup download of a valid SQLite file |

## Adding a test

```js
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { startServer, team, SKU, OUT } = require("./helpers");

let srv, t;
before(async () => { srv = await startServer(); t = await team(srv); });
after(() => srv.stop());

test("cashiers can add customers", async () => {
  const r = await t.cashier.write([{ op: "set", path: "customers/x", data: { name: "X" } }]);
  assert.equal(r.status, 200);
});
```

`t.owner`, `t.manager`, `t.cashier`, `t.cashier2` and `t.viewer` are logged-in clients with `get`, `post`, `write(ops)`, `doc(path)` and `query(q)`. `SKU` and `OUT` name seed items and outlets with known stock (see `helpers.js`).

## Continuous integration

`.github/workflows/test.yml` runs `npm run check` and `npm test` on Node 22 and 24 for every push and pull request.

## What the tests don't cover

The browser screens themselves (layout, clicks) aren't covered by this suite. They were checked by hand and with Playwright scripts during development. The live Shopify and WhatsApp services are also out of scope: the stand-ins follow their documented request formats, but a real connection should still be checked once after setup with **Test connection** and **Send test**.
