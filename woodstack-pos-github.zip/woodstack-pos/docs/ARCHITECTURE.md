# Architecture

WOODstack POS is a single Node.js process with an embedded SQLite database. It serves one web page (`public/index.html`) that every register, back-office PC and phone opens in a browser. There are no outside npm packages: only Node's built-in `http`, `crypto` and `node:sqlite`.

```mermaid
flowchart LR
  subgraph Stores["11 stores, warehouse, back office"]
    R1[Register browser] & R2[Back-office browser] & H[Handheld RFID / barcode]
  end
  Caddy[Caddy<br/>HTTPS certificates] --> Node
  R1 & R2 & H -- HTTPS --> Caddy
  subgraph Server["DigitalOcean server"]
    Node[server.js<br/>API, rules, live updates] --> DB[(SQLite<br/>data/pos.db)]
    Node --> Bk[(Nightly backups<br/>data/backups)]
    Node --- Shop[shopify.js]
    Node --- Al[alerts.js]
    Node --- Rep[reports.js]
  end
  Shop <-- Admin GraphQL 2026-10 --> Shopify[(Shopify<br/>WOODstack.com)]
  Al -- messages --> WA[(WhatsApp<br/>Meta Cloud API or CallMeBot)]
```

## Files

| File | What it holds |
|---|---|
| `server.js` | HTTP server, sessions, staff, document store, every business rule (permissions, discount limits, Gold SKUs, store credit), time clock, order packing, sales import, backups, CLI |
| `shopify.js` | Shopify connection: login (client credentials grant), order import, stock push, fulfillment |
| `alerts.js` | WhatsApp alerts for stock going below zero |
| `reports.js` | Report builder datasets and the grouping and aggregation engine |
| `public/index.html` | The whole app UI: markup, styles and script in one file |
| `public/ws-client.js` | The browser's connection to the server: login screen, document reads and writes, live updates |
| `install.sh` | One-command install and update for Ubuntu (Node 24, Caddy, systemd, firewall, owner login) |
| `data/seed.json` | Starting data used on the very first start: outlets, registers, taxes, payment types, starter catalog |

## How a request flows

1. The browser calls `/api/...` with its session cookie. `ws-client.js` gives the page a small database-like interface: `db.doc(path).get/set/update/merge`, `db.collection(path).where(...).onSnapshot(...)`.
2. `server.js` checks the session, then the **permission rules** for the collection and role, then the **business rules** for that kind of document. For example, a new sale is checked against the seller's discount limit, Gold SKUs and the customer's store credit.
3. The writes run in **one SQLite transaction**. Derived changes, such as store credit balances and history entries, are written in the same transaction, so they can't drift apart.
4. After the commit, every change is sent to every open screen over **Server-Sent Events** (`/api/events`). Screens update without polling or reloading.
5. Hooks run after the commit. `shopify.js` marks changed stock to send to Shopify, and `alerts.js` notes anything that dropped below zero.

## Data model

Everything a store works with is a JSON **document** in the `docs` table (`path`, `coll`, `id`, `data`, `version`). Staff logins, sessions and integration settings live in their own tables, which the API never exposes as documents.

| Path | Holds |
|---|---|
| `config/main` | `outlets[]` (name, address, `prefix`, tax `rate`, clothing exemption threshold `cfMin`), `registers[]` (`name`, `outlet`), `payments[]` |
| `config/discounts` | `roles: { cashier, manager }`: discount limit per role, in % |
| `config/quickkeys` | `keys: [{ fid, label, color }]`: Sell screen quick buttons |
| `catalog/c000…` | Products, packed into chunks of about 180 KB: `fams: { fid: { n, b, t, c, cn, msrp, md1, md2, co, ip, stage, pr, tx, gold, x, v: { sku: { o, st: { outletIndex: qty } } } } }` |
| `sales/{date}_r{register}` | One register's day: `sales: [ { id, no, t, oi, ri, lines[], sub, tax, tot, cost, items, pays[], cust, by, st, cbal? } ]`. Imported history uses `{date}_imp{outlet}` |
| `customers/{id}` | `name, phone, email, note, cat (customer, reseller, vip, employee, fnf), link (staff id), spent, visits, last, credit` |
| `credit/{id}` | Store credit history: `cust, amt (+ added / − used), bal (after), type, sale, note, by, at` |
| `orders/{shopifyId}` | Online order: Shopify fields (`name, ship, lines[], total, method…`) plus picking state (`st, loc, picked, packedAt, tracking…`) |
| `registers/r{n}` | Register open or closed, opening float |
| `closures/{id}` | Register close: expected against counted per payment type, over or short |
| `transfers/{id}` | Stock moving between outlets: `from, to, items[], st (draft, sent, received, cancelled)` |
| `adjustments/{id}`, `counts/{id}` | Stock counts and RFID count sessions, with before and after |
| `rfid/pairs` | `pairs: { tagEPC: sku }` for tags that don't carry a UPC |
| `shifts/{id}` | Schedule: `uid, oi, date, start, end, breakMin, note` |
| `punches/{id}` | Time clock: `uid, oi, date, in, out, open, breaks[], edits[]` |
| `reports/{id}` | Saved report builder reports |

Other tables:

| Table | Holds |
|---|---|
| `users` | Staff logins: name, login, scrypt password hash and salt, role, active, `disc` (individual discount limit) |
| `sessions` | Session tokens with a 30-day sliding expiry |
| `meta` | Server secret (for approval tokens), last backup time, Shopify and alert settings and state |
| `shopify_variants` | Barcode or SKU → Shopify inventory item and variant |
| `shopify_pushed` | Last quantity sent to Shopify per SKU, so unchanged items aren't re-sent |

### Why the catalog is chunked
A product family, with all its sizes and per-outlet stock, sits inside a chunk document. That keeps the full catalog, about 90,000 variants, to a few dozen documents that every register can load and keep live. Stock changes use `__inc`, so two registers selling the same item at the same moment can't overwrite each other.

### Why sales are one document per register per day
A register only appends to its own day (`__push`), so registers never contend. Reports read days by date range through an index on `json_extract(data, '$.date')`.

## Business rules (enforced on the server)

| Rule | Where |
|---|---|
| Role permissions per collection | `canWrite()` in `server.js` |
| Discount limits per role and person; approvals from someone whose limit covers it | `checkSaleLines()` and `/api/approve` |
| Gold SKUs: only owners mark them, price them, or approve discounts on them | `checkSaleLines()` and `checkCatalogDoc()` |
| Completed sales can't be edited, only voided | `checkSalesDoc()` |
| Store credit: balance can't go negative or be edited directly; voids refund it | `creditDeltas()` and `applyCreditInTx()` |
| Packing needs every item scanned unless a manager forces it | `orderAction()` |
| Staff hierarchy: who can create and change whom, keep one owner | `saveStaff()` |
| Login and approval rate limit: 10 failures per address per 15 minutes | `tooMany()` |

## Background jobs

| Job | When |
|---|---|
| Nightly database backup (`VACUUM INTO`), keeps 30 | Checked every 30 minutes; once per day |
| Shopify order import | Every 2 minutes |
| Send changed stock to Shopify | Every 20 seconds when something changed |
| Re-match Shopify products | Every 6 hours |
| Re-send all stock to Shopify | Every 24 hours |
| Group and send negative-stock alerts | Every minute |
| Expired session clean-up | Hourly |

## Security
- Passwords hashed with scrypt and a per-user salt. Sessions are random 256-bit tokens in an HttpOnly, SameSite=Lax cookie (Secure behind HTTPS).
- Approval codes are HMAC-signed with a per-install secret and expire after 15 minutes.
- Strict Content-Security-Policy (`default-src 'self'`; only Google Fonts allowed). `X-Frame-Options: DENY`, `nosniff`, and same-origin checks on every write.
- Shopify secrets, the WhatsApp token and CallMeBot keys are stored server-side only and sent to screens masked.
- The service runs as an unprivileged `woodstack` user under systemd with `ProtectSystem=strict`. Only `data/` is writable.
- The database and backups are kept out of git by `.gitignore`.

## Configuration (environment variables)

| Variable | Default | Purpose |
|---|---|---|
| `PORT`, `HOST` | `8080`, `127.0.0.1` | Where the server listens. Caddy proxies HTTPS to it |
| `DATA_DIR` | `./data` | Database, backups and `seed.json` |
| `KEEP_BACKUPS` | `30` | Nightly backups to keep |
| `STORE_TZ` | `America/New_York` | Time zone for report dates |
| `SECURE_COOKIES` | (off) | Force `Secure` cookies even without `X-Forwarded-Proto` |
| `ALERT_FLUSH_MS` | `60000` | How long alerts are grouped before sending |
| `SHOPIFY_TEST_BASE`, `WHATSAPP_TEST_BASE`, `CALLMEBOT_TEST_BASE` | (unset) | Point integrations at stand-in services; used by the tests |
