/*
 * Connects the Woodstack POS page to its own server.
 * Provides the same small interface the page was written against
 * (claude.use("db" | "user" | "downloads")), backed by /api on this server,
 * and shows the login screen until someone signs in.
 */
(() => {
  "use strict";
  const isObj = v => v && typeof v === "object" && !Array.isArray(v);
  const freeze = o => Object.freeze(o);
  const err = (code, message) => Object.assign(new Error(message), { code, message });

  async function call(path, opts = {}) {
    let res;
    try {
      res = await fetch(path, { credentials: "same-origin", headers: opts.body ? { "Content-Type": "application/json" } : {}, ...opts, body: opts.body ? JSON.stringify(opts.body) : undefined });
    } catch { throw err("unavailable", "Can’t reach the POS server. Check the internet connection."); }
    const j = await res.json().catch(() => ({}));
    if (res.status === 401 && path === "/api/me") throw err("unauthenticated", "Not logged in");
    if (res.status === 401 && path !== "/api/login") { showLogin("Your session ended. Log in again."); throw err("unavailable", "Not logged in"); }
    if (!res.ok) throw err(res.status === 403 || res.status === 400 ? "invalid_argument" : res.status === 413 ? "quota_exceeded" : "unavailable", j.error || "Request failed");
    return j;
  }

  /* ---------- live document cache + subscriptions ---------- */
  const docListeners = new Map();   // path -> Set(fn)
  const queryListeners = new Set(); // {coll, where, orderBy, dir, limit, map, next}
  let es = null, connected = false;

  const snapOf = d => freeze({ id: d.id, exists: !!d.exists, data: () => d.exists ? d.data : undefined, metadata: freeze({ fromCache: false, hasPendingWrites: false }), _v: d.version || 0 });

  function cmp(a, op, b) {
    switch (op) {
      case "==": return a === b; case "!=": return a !== b && a !== undefined;
      case "<": return a < b; case "<=": return a <= b; case ">": return a > b; case ">=": return a >= b;
      case "in": return b.includes(a); case "not-in": return a !== undefined && !b.includes(a);
      case "array-contains": return Array.isArray(a) && a.includes(b);
    }
    return false;
  }
  const matches = (q, data) => q.where.every(([f, op, v]) => cmp(data?.[f], op, v));
  function emitQuery(q, changes) {
    let docs = [...q.map.values()];
    if (q.orderBy) {
      const f = q.orderBy, s = q.dir === "desc" ? -1 : 1;
      docs.sort((x, y) => { const a = x.data()[f], b = y.data()[f]; if (a === b) return 0; if (a === undefined) return 1; if (b === undefined) return -1; return (a < b ? -1 : 1) * s; });
    } else docs.sort((x, y) => (x.id < y.id ? -1 : x.id > y.id ? 1 : 0));
    if (q.limit) docs = docs.slice(0, q.limit);
    q.next(freeze({ docs, size: docs.length, empty: !docs.length, docChanges: () => changes, metadata: freeze({ fromCache: false, hasPendingWrites: false }) }));
  }
  function applyDoc(d) {
    const s = snapOf(d);
    for (const fn of docListeners.get(d.path) || []) fn(s);
    for (const q of queryListeners) {
      if (q.coll !== d.coll) continue;
      const had = q.map.get(d.id);
      if (had && had._v >= d.version && d.exists) continue;
      if (d.exists && matches(q, d.data)) { q.map.set(d.id, s); emitQuery(q, [{ type: had ? "modified" : "added", doc: s, oldIndex: -1, newIndex: -1 }]); }
      else if (had) { q.map.delete(d.id); emitQuery(q, [{ type: "removed", doc: had, oldIndex: -1, newIndex: -1 }]); }
    }
  }
  function connect() {
    if (es) return;
    es = new EventSource("/api/events");
    es.addEventListener("doc", e => { try { applyDoc(JSON.parse(e.data)); } catch {} });
    es.onopen = () => {
      const wasDown = !connected; connected = true; setStatus(true);
      if (wasDown && reconnects++) resync(); // catch up on anything missed while disconnected
    };
    es.onerror = () => { connected = false; setStatus(false); };
  }
  let reconnects = 0;
  async function resync() {
    for (const [p, fns] of docListeners) if (fns.size) call("/api/doc?path=" + encodeURIComponent(p)).then(d => { const s = snapOf(d); fns.forEach(fn => fn(s)); }).catch(() => {});
    for (const q of queryListeners) loadQuery(q).catch(() => {});
  }
  async function loadQuery(q) {
    const { docs } = await call("/api/query", { method: "POST", body: { coll: q.coll, where: q.where, orderBy: q.orderBy, dir: q.dir, limit: q.limit ? Math.max(q.limit, 1000) : 0 } });
    q.map = new Map(docs.map(d => [d.id, snapOf(d)]));
    emitQuery(q, docs.map(d => ({ type: "added", doc: q.map.get(d.id), oldIndex: -1, newIndex: -1 })));
  }
  function setStatus(ok) { const p = document.getElementById("sync"); if (p && p.dataset.ws !== String(ok)) { p.dataset.ws = String(ok); p.textContent = ok ? "Live" : "Reconnecting…"; p.className = "pill " + (ok ? "good" : "warn"); } }

  async function write(ops) {
    const { docs } = await call("/api/write", { method: "POST", body: { ops } });
    docs.forEach(applyDoc);
    return docs;
  }

  /* ---------- refs ---------- */
  function docRef(path) {
    const segs = path.split("/");
    if (segs.length % 2 || segs.some(s => !s)) throw new TypeError("Document paths need an even number of segments: " + path);
    return freeze({
      id: segs[segs.length - 1], path,
      get: async () => snapOf(await call("/api/doc?path=" + encodeURIComponent(path))),
      set: data => write([{ op: "set", path, data }]).then(() => {}),
      update: data => write([{ op: "update", path, data }]).then(() => {}),
      merge: data => write([{ op: "merge", path, data }]).then(() => {}),
      delete: () => write([{ op: "delete", path }]).then(() => {}),
      collection: sub => collRef(path + "/" + sub),
      onSnapshot(next, error) {
        connect();
        let set = docListeners.get(path); if (!set) docListeners.set(path, set = new Set());
        set.add(next);
        call("/api/doc?path=" + encodeURIComponent(path)).then(d => next(snapOf(d))).catch(e => error && error(e));
        return () => set.delete(next);
      }
    });
  }
  function query(coll, where = [], orderBy = null, dir = "asc", limit = 0) {
    return {
      where: (f, op, v) => query(coll, [...where, [f, op, v]], orderBy, dir, limit),
      orderBy: (f, d = "asc") => query(coll, where, f, d, limit),
      limit: n => query(coll, where, orderBy, dir, n),
      async get() {
        const q = { coll, where, orderBy, dir, limit, map: new Map(), next: () => {} };
        let out; q.next = s => { out = s; }; await loadQuery(q); return out;
      },
      onSnapshot(next, error) {
        connect();
        const q = { coll, where, orderBy, dir, limit, map: new Map(), next };
        queryListeners.add(q);
        loadQuery(q).catch(e => error && error(e));
        return () => queryListeners.delete(q);
      }
    };
  }
  function collRef(path) {
    const segs = path.split("/");
    if (segs.length % 2 === 0 || segs.some(s => !s)) throw new TypeError("Collection paths need an odd number of segments: " + path);
    const genId = () => Array.from(crypto.getRandomValues(new Uint8Array(15)), b => "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"[b % 62]).join("").slice(0, 20);
    return freeze({ path, ...query(path), doc: id => docRef(path + "/" + (id || genId())), async add(data) { const r = docRef(path + "/" + genId()); await r.set(data); return r; } });
  }
  const dbApi = freeze({ doc: docRef, collection: collRef });

  /* ---------- who is signed in ---------- */
  let me = null;
  const level = { viewer: 0, cashier: 1, manager: 2, owner: 3 };
  const profileCache = {};
  const userApi = freeze({
    id: async () => me?.id ?? null,
    me: async () => ({ id: me?.id, name: me?.name || "", guest: false }),
    isOwner: () => me?.role === "owner",
    canEdit: () => level[me?.role] >= 2,
    can: name => name === "data.write" ? level[me?.role] >= 1 : null,
    async profiles(ids) {
      const need = ids.filter(id => !(id in profileCache));
      if (need.length) Object.assign(profileCache, await call("/api/profiles?ids=" + encodeURIComponent(need.join(","))).catch(() => ({})));
      return Object.fromEntries(ids.map(id => [id, profileCache[id] || { id, name: "" }]));
    },
    search: async () => []
  });

  const downloadsApi = freeze({
    async save({ filename, data }) {
      const blob = data instanceof Blob ? data : new Blob([data], { type: "text/csv;charset=utf-8" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = filename;
      document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    }
  });

  /* ---------- login screen ---------- */
  let ready, resolveReady;
  ready = new Promise(r => (resolveReady = r));
  function showLogin(message) {
    if (document.getElementById("wsLogin")) return;
    const box = document.createElement("div");
    box.id = "wsLogin";
    box.innerHTML = `<form class="login-card" id="wsLoginForm" novalidate>
      <div class="brand">WOODstack <small>POS</small></div>
      <p class="muted" style="margin:0">${message || "Log in with the staff login a manager gave you."}</p>
      <label>Login<input id="wsLoginUser" type="text" autocomplete="username" autocapitalize="none" required></label>
      <label>Password<input id="wsLoginPw" type="password" autocomplete="current-password" required></label>
      <div id="wsLoginErr" class="neg" role="alert"></div>
      <button class="btn pri" type="submit" style="padding:12px;font-size:16px">Log in</button>
    </form>`;
    document.body.append(box);
    const f = document.getElementById("wsLoginForm");
    f.addEventListener("submit", async e => {
      e.preventDefault();
      const btn = f.querySelector("button"); btn.disabled = true; document.getElementById("wsLoginErr").textContent = "";
      try {
        const { user } = await call("/api/login", { method: "POST", body: { login: document.getElementById("wsLoginUser").value, password: document.getElementById("wsLoginPw").value } });
        const first = !me; me = user; box.remove();
        if (first) resolveReady(); else location.reload();
      } catch (x) { document.getElementById("wsLoginErr").textContent = x.message; btn.disabled = false; }
    });
    setTimeout(() => document.getElementById("wsLoginUser")?.focus(), 50);
  }
  async function boot() {
    try { const { user } = await call("/api/me"); me = user; resolveReady(); }
    catch (e) { showLogin(e.code === "unauthenticated" ? "" : "Can’t reach the POS server right now. Check the connection, then log in."); }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();

  const caps = { db: dbApi, user: userApi, downloads: downloadsApi };
  window.claude = freeze({ use: name => ready.then(() => caps[name] ?? null) });

  /* extras for the self-hosted version: staff, backups, log out */
  window.WS = freeze({
    selfHosted: true,
    me: () => me,
    async refreshMe() { try { me = (await call("/api/me")).user; } catch {} return me; },
    api: call,
    async logout() { await call("/api/logout", { method: "POST" }).catch(() => {}); location.reload(); }
  });
})();
